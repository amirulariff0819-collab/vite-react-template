import { useCallback, useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Eraser, PenLine } from "lucide-react";

export function SignaturePad({ onSave }: { onSave?: (dataUrl: string) => void }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const drawing = useRef(false);
  const lastPos = useRef<{ x: number; y: number } | null>(null);
  const [hasSignature, setHasSignature] = useState(false);

  const getPos = (e: MouseEvent | TouchEvent | React.MouseEvent | React.TouchEvent, canvas: HTMLCanvasElement) => {
    const rect = canvas.getBoundingClientRect();
    const src = "touches" in e && e.touches?.length ? e.touches[0] : (e as MouseEvent);
    return {
      x: (src.clientX - rect.left) * (canvas.width / rect.width),
      y: (src.clientY - rect.top) * (canvas.height / rect.height),
    };
  };

  const startDraw = (e: React.MouseEvent | React.TouchEvent) => {
    e.preventDefault();
    if (!canvasRef.current) return;
    drawing.current = true;
    lastPos.current = getPos(e, canvasRef.current);
  };

  const draw = useCallback((e: MouseEvent | TouchEvent | React.MouseEvent | React.TouchEvent) => {
    if (!drawing.current || !canvasRef.current) return;
    if ("preventDefault" in e) e.preventDefault();
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    if (!ctx || !lastPos.current) return;
    const pos = getPos(e, canvas);
    ctx.beginPath();
    ctx.moveTo(lastPos.current.x, lastPos.current.y);
    ctx.lineTo(pos.x, pos.y);
    ctx.strokeStyle = "#101733";
    ctx.lineWidth = 2.4;
    ctx.lineCap = "round";
    ctx.stroke();
    lastPos.current = pos;
    setHasSignature(true);
  }, []);

  const stopDraw = () => {
    drawing.current = false;
  };

  const clear = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    canvas.getContext("2d")?.clearRect(0, 0, canvas.width, canvas.height);
    setHasSignature(false);
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const handler = (e: TouchEvent) => draw(e);
    canvas.addEventListener("touchmove", handler, { passive: false });
    return () => canvas.removeEventListener("touchmove", handler);
  }, [draw]);

  return (
    <div>
      <canvas
        ref={canvasRef}
        width={960}
        height={240}
        onMouseDown={startDraw}
        onMouseMove={draw}
        onMouseUp={stopDraw}
        onMouseLeave={stopDraw}
        onTouchStart={startDraw}
        onTouchEnd={stopDraw}
        className="block h-32 w-full cursor-crosshair rounded-xl border border-dashed border-primary/35 bg-secondary/60"
      />
      <div className="mt-3 flex flex-wrap items-center gap-2">
        <Button type="button" variant="outline" size="sm" onClick={clear}>
          <Eraser className="size-4" /> Clear
        </Button>
        <Button
          type="button"
          size="sm"
          disabled={!hasSignature}
          onClick={() => canvasRef.current && onSave?.(canvasRef.current.toDataURL())}
        >
          <PenLine className="size-4" /> Save signature
        </Button>
        <span className="text-xs text-muted-foreground">Draw with mouse or finger</span>
      </div>
    </div>
  );
}
