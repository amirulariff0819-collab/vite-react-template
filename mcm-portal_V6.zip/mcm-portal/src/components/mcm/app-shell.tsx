import { Link, useRouterState } from "@tanstack/react-router";
import { useEffect, useState, type ReactNode } from "react";
import {
  FileText,
  ClipboardList,
  Settings as SettingsIcon,
  LogOut,
  PanelLeftClose,
  PanelLeftOpen,
  LayoutDashboard,
  Database,
  Wifi,
  WifiOff,
  ShieldCheck,
  MoreHorizontal,
  Clock,
} from "lucide-react";
import logoUrl from "@/assets/mcm-logo.png";
import { useAuth, initials } from "@/lib/auth";
import { cn } from "@/lib/utils";
import { Pill } from "./primitives";
import { useOnlineStatus } from "@/hooks/use-online-status";
import { useIdleLogout } from "@/hooks/use-idle-logout";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

const NAV = [
  { to: "/dashboard", label: "Overview", short: "Home", icon: LayoutDashboard },
  { to: "/quotation", label: "Quotation", short: "Quote", icon: FileText },
  { to: "/service-request", label: "Service Request", short: "SRF", icon: ClipboardList },
  { to: "/summary", label: "Summary", short: "Records", icon: Database },
  { to: "/settings", label: "Settings", short: "Settings", icon: SettingsIcon },
  { to: "/admin", label: "Admin Console", short: "Admin", icon: ShieldCheck, admin: true },
] as const;

type NavItem = (typeof NAV)[number];

export function AppShell({
  title,
  subtitle,
  children,
}: {
  title: string;
  subtitle?: string;
  children: ReactNode;
}) {
  const { user, logout, ready } = useAuth();
  const [collapsed, setCollapsed] = useState(false);
  const [moreOpen, setMoreOpen] = useState(false);
  const online = useOnlineStatus();
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  const { secondsLeft, stayActive, idleTimeoutMinutes } = useIdleLogout(() => {
    toast.info(`Signed out after ${idleTimeoutMinutes} min of inactivity. Your draft is saved.`);
    logout();
  });

  useEffect(() => {
    if (ready && !user) window.location.replace("/");
  }, [ready, user]);

  if (!ready || !user) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="size-10 animate-spin rounded-full border-2 border-primary/25 border-t-primary" />
      </div>
    );
  }

  const items: NavItem[] = NAV.filter(
    (n) => !("admin" in n && n.admin) || user.role === "admin",
  ) as unknown as NavItem[];
  const primary = items.slice(0, 4);
  const overflow = items.slice(4);

  return (
    <div className="flex min-h-screen bg-background">
      {/* ── Desktop sidebar ─────────────────────────────────────────── */}
      <aside
        className={cn(
          "bg-gradient-deep no-print sticky top-0 hidden h-screen shrink-0 flex-col overflow-hidden transition-[width] duration-300 lg:flex",
          collapsed ? "w-[76px]" : "w-64",
        )}
      >
        <div className={cn("flex items-center justify-center px-4 py-6", collapsed && "px-0 py-5")}>
          <img
            src={logoUrl}
            alt="Metrology Corporation Malaysia logo"
            className={cn(
              "mx-auto block object-contain brightness-0 invert transition-all",
              collapsed ? "h-7 w-auto" : "h-14 w-auto",
            )}
          />
        </div>

        <nav className="flex-1 space-y-1 p-3">
          {items.map((item) => (
            <SidebarLink key={item.to} item={item} active={pathname === item.to} collapsed={collapsed} />
          ))}
        </nav>

        <div className="border-t border-white/10 p-3">
          {!collapsed && (
            <div className="mb-3 flex items-center gap-3 rounded-xl bg-white/5 px-3 py-2.5">
              <span className="bg-gradient-brand flex size-9 shrink-0 items-center justify-center rounded-full text-sm font-extrabold text-primary-foreground">
                {initials(user)}
              </span>
              <div className="min-w-0">
                <div className="truncate text-xs font-bold text-white">
                  {user.full_name || user.username}
                </div>
                <div className="truncate text-[10px] tracking-wider text-white/45 uppercase">
                  {user.role || "staff"}
                </div>
              </div>
            </div>
          )}
          <button
            onClick={logout}
            title="Log out"
            className={cn(
              "flex w-full items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-xs font-semibold text-white/70 transition-colors hover:bg-destructive/25 hover:text-white",
              collapsed && "justify-center px-0",
            )}
          >
            <LogOut className="size-4" />
            {!collapsed && "Log out"}
          </button>
        </div>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        {/* ── Header ────────────────────────────────────────────────── */}
        <header className="no-print sticky top-0 z-40 grid h-16 grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-3 border-b border-border/70 bg-card/80 px-4 backdrop-blur-xl sm:gap-4 sm:px-8">
          <div className="flex shrink-0 items-center gap-2">
            <button
              onClick={() => setCollapsed((c) => !c)}
              className="hidden rounded-lg p-2 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground lg:block"
              aria-label="Toggle navigation"
            >
              {collapsed ? (
                <PanelLeftOpen className="size-5" />
              ) : (
                <PanelLeftClose className="size-5" />
              )}
            </button>
            <img
              src={logoUrl}
              alt="MCM logo"
              className="h-7 w-auto shrink-0 object-contain lg:hidden dark:brightness-0 dark:invert"
            />
          </div>

          <div className="min-w-0">
            <div className="truncate text-sm font-bold">{title}</div>
            {subtitle && (
              <div className="hidden truncate text-xs text-muted-foreground sm:block">
                {subtitle}
              </div>
            )}
          </div>

          <div className="flex shrink-0 items-center gap-2 sm:gap-3">
            <Pill tone={online ? "success" : "warning"}>
              {online ? (
                <>
                  <Wifi className="size-3.5" />
                  <span className="hidden sm:inline">Online</span>
                </>
              ) : (
                <>
                  <WifiOff className="size-3.5" />
                  <span className="hidden sm:inline">Offline</span>
                </>
              )}
            </Pill>
            <span className="bg-gradient-brand hidden size-9 items-center justify-center rounded-full text-sm font-extrabold text-primary-foreground sm:flex">
              {initials(user)}
            </span>
            {/* Logout lives in the sidebar on desktop — show it here only on small screens */}
            <button
              onClick={logout}
              aria-label="Log out"
              className="flex items-center gap-1.5 rounded-xl border border-border bg-secondary/60 px-2.5 py-2 text-xs font-bold text-foreground transition-colors hover:bg-destructive/10 hover:text-destructive active:scale-95 lg:hidden"
            >
              <LogOut className="size-4" />
              <span className="hidden sm:inline">Log out</span>
            </button>
          </div>
        </header>

        {/* ── Tablet segmented nav ──────────────────────────────────── */}
        <nav className="no-print hidden gap-1.5 overflow-x-auto border-b border-border/70 bg-card/60 px-4 py-2.5 backdrop-blur-xl md:flex lg:hidden">
          {items.map((item) => {
            const active = pathname === item.to;
            const Icon = item.icon;
            return (
              <Link
                key={item.to}
                to={item.to}
                className={cn(
                  "flex shrink-0 items-center gap-2 rounded-xl px-3.5 py-2 text-xs font-bold transition-all",
                  active
                    ? "bg-gradient-brand text-primary-foreground shadow-lift"
                    : "text-muted-foreground hover:bg-secondary hover:text-foreground",
                )}
              >
                <Icon className="size-4" /> {item.label}
              </Link>
            );
          })}
        </nav>

        <main className="mx-auto w-full max-w-6xl flex-1 px-4 pt-6 pb-28 sm:px-8 sm:py-8 md:pb-8">
          {children}
        </main>

        {/* ── Mobile bottom tab bar ─────────────────────────────────── */}
        <nav className="no-print fixed inset-x-0 bottom-0 z-50 border-t border-border/70 bg-card/85 pb-[env(safe-area-inset-bottom)] backdrop-blur-2xl md:hidden">
          <div className="mx-auto flex max-w-lg items-stretch justify-between px-2 py-1.5">
            {primary.map((item) => {
              const active = pathname === item.to;
              const Icon = item.icon;
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  className="group relative flex flex-1 flex-col items-center gap-1 rounded-2xl px-1 py-2 transition-transform active:scale-95"
                >
                  <span
                    className={cn(
                      "flex size-9 items-center justify-center rounded-xl transition-all",
                      active
                        ? "bg-gradient-brand text-primary-foreground shadow-lift"
                        : "text-muted-foreground group-hover:bg-secondary",
                    )}
                  >
                    <Icon className="size-[18px]" />
                  </span>
                  <span
                    className={cn(
                      "text-[10px] font-bold tracking-tight",
                      active ? "text-primary" : "text-muted-foreground",
                    )}
                  >
                    {item.short}
                  </span>
                </Link>
              );
            })}

            <Sheet open={moreOpen} onOpenChange={setMoreOpen}>
              <SheetTrigger asChild>
                <button className="group flex flex-1 flex-col items-center gap-1 rounded-2xl px-1 py-2 transition-transform active:scale-95">
                  <span
                    className={cn(
                      "flex size-9 items-center justify-center rounded-xl transition-all",
                      overflow.some((o) => o.to === pathname)
                        ? "bg-gradient-brand text-primary-foreground shadow-lift"
                        : "text-muted-foreground group-hover:bg-secondary",
                    )}
                  >
                    <MoreHorizontal className="size-[18px]" />
                  </span>
                  <span className="text-[10px] font-bold tracking-tight text-muted-foreground">
                    More
                  </span>
                </button>
              </SheetTrigger>
              <SheetContent side="bottom" className="rounded-t-3xl border-border/70">
                <SheetHeader className="text-left">
                  <SheetTitle className="text-base">Menu</SheetTitle>
                </SheetHeader>
                <div className="space-y-2 p-4 pt-0">
                  <div className="flex items-center gap-3 rounded-2xl bg-secondary/60 px-3 py-3">
                    <span className="bg-gradient-brand flex size-11 items-center justify-center rounded-2xl text-base font-extrabold text-primary-foreground">
                      {initials(user)}
                    </span>
                    <div className="min-w-0">
                      <div className="truncate text-sm font-bold">
                        {user.full_name || user.username}
                      </div>
                      <div className="truncate text-[10px] font-semibold tracking-wider text-muted-foreground uppercase">
                        {user.role || "staff"}
                      </div>
                    </div>
                  </div>

                  {overflow.map((item) => {
                    const Icon = item.icon;
                    return (
                      <Link
                        key={item.to}
                        to={item.to}
                        onClick={() => setMoreOpen(false)}
                        className={cn(
                          "flex items-center gap-3 rounded-2xl px-3.5 py-3 text-sm font-semibold transition-colors",
                          pathname === item.to
                            ? "bg-primary/10 text-primary"
                            : "hover:bg-secondary",
                        )}
                      >
                        <Icon className="size-[18px]" /> {item.label}
                      </Link>
                    );
                  })}

                </div>
              </SheetContent>
            </Sheet>
          </div>
        </nav>
      </div>

      {/* ── Idle warning ──────────────────────────────────────────── */}
      {secondsLeft !== null && (
        <div className="no-print fixed inset-x-0 bottom-24 z-[60] mx-auto flex w-[min(92vw,26rem)] items-center gap-3 rounded-2xl border border-warning/40 bg-card px-4 py-3 shadow-lift md:bottom-6">
          <Clock className="size-5 shrink-0 text-warning-foreground" />
          <p className="min-w-0 flex-1 text-xs font-semibold">
            Inactive — signing out in {secondsLeft}s.
            <span className="block font-normal text-muted-foreground">
              Your work is auto-saved as a draft.
            </span>
          </p>
          <Button size="sm" onClick={stayActive}>
            Stay
          </Button>
        </div>
      )}
    </div>
  );
}

function SidebarLink({
  item,
  active,
  collapsed,
}: {
  item: NavItem;
  active: boolean;
  collapsed: boolean;
}) {
  const Icon = item.icon;
  return (
    <Link
      to={item.to}
      title={collapsed ? item.label : undefined}
      className={cn(
        "group flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-all",
        collapsed && "justify-center px-0",
        active
          ? "bg-white/12 text-white shadow-lift ring-1 ring-white/15"
          : "text-white/60 hover:bg-white/8 hover:text-white",
      )}
    >
      <Icon className="size-[18px] shrink-0" />
      {!collapsed && <span className="truncate">{item.label}</span>}
      {!collapsed && "admin" in item && item.admin && (
        <span className="ml-auto rounded-md bg-primary/30 px-1.5 py-0.5 text-[9px] font-bold tracking-widest text-white/85">
          ADMIN
        </span>
      )}
    </Link>
  );
}
