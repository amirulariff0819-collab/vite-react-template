import { useEffect, useMemo, useState } from "react";
import {
  Users,
  Tags,
  History,
  ShieldAlert,
  ShieldCheck,
  Trash2,
  Plus,
  Save,
  Timer,
  Search,
  RefreshCw,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Panel,
  FieldLabel,
  TextField,
  SelectField,
  Pill,
  PageHeading,
} from "@/components/mcm/primitives";
import { sbGet, sbRpc, sbInsert, sbPatch, sbDelete, fmt, type Service } from "@/lib/mcm-api";
import { useAuth } from "@/lib/auth";
import { readSettings, writeSettings, DEFAULT_SETTINGS } from "@/lib/app-settings";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

type TabKey = "users" | "prices" | "history" | "session";

const TABS: { key: TabKey; label: string; icon: typeof Users }[] = [
  { key: "users", label: "Users", icon: Users },
  { key: "prices", label: "Price list", icon: Tags },
  { key: "history", label: "Login history", icon: History },
  { key: "session", label: "Session", icon: Timer },
];

type AdminUser = {
  id: number | string;
  username: string;
  full_name?: string | null;
  role?: string | null;
};

type LogRow = {
  id: number;
  username: string;
  full_name?: string;
  role?: string;
  logged_in_at: string;
};

export function AdminPage() {
  const { user } = useAuth();
  const [tab, setTab] = useState<TabKey>("users");

  if (user?.role !== "admin") {
    return (
      <div className="surface mx-auto max-w-md p-10 text-center">
        <ShieldAlert className="mx-auto mb-4 size-10 text-primary" />
        <h2 className="text-lg font-bold">Admin access only</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          You don&apos;t have permission to view this page.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <PageHeading
        title="Admin Console"
        subtitle="Manage staff accounts, calibration pricing, sign-in activity and session rules"
      />

      <div className="no-print -mx-1 flex gap-1.5 overflow-x-auto px-1 pb-1">
        {TABS.map((t) => {
          const Icon = t.icon;
          const active = tab === t.key;
          return (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={cn(
                "flex shrink-0 items-center gap-2 rounded-xl px-3.5 py-2.5 text-xs font-bold transition-all active:scale-95",
                active
                  ? "bg-gradient-brand text-primary-foreground shadow-lift"
                  : "bg-secondary/60 text-muted-foreground hover:text-foreground",
              )}
            >
              <Icon className="size-4" /> {t.label}
            </button>
          );
        })}
      </div>

      {tab === "users" && <UsersTab currentUsername={user.username} />}
      {tab === "prices" && <PricesTab />}
      {tab === "history" && <HistoryTab />}
      {tab === "session" && <SessionTab />}
    </div>
  );
}

/* ─── Users ──────────────────────────────────────────────────────── */

function UsersTab({ currentUsername }: { currentUsername: string }) {
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [form, setForm] = useState({ username: "", full_name: "", password: "", role: "staff" });

  // Prefer the security-definer RPCs (supabase-security.sql) so the staff table
  // itself stays unreadable; fall back to direct table access when absent.
  const rpcOr = async <T,>(fn: string, args: Record<string, unknown>, fallback: () => Promise<T>) => {
    try {
      return await sbRpc<T>(fn, args);
    } catch (e) {
      if (/404|not find|does not exist/i.test((e as Error).message)) return fallback();
      throw e;
    }
  };

  const load = () => {
    setLoading(true);
    rpcOr<AdminUser[]>("mcm_list_users", {}, () =>
      sbGet<AdminUser[]>("mcm_users?select=id,username,full_name,role&order=id"),
    )
      .then((d) => setUsers(Array.isArray(d) ? d : []))
      .catch(() => toast.error("Could not load users."))
      .finally(() => setLoading(false));
  };

  useEffect(load, []);

  const addUser = async () => {
    if (!form.username.trim() || !form.password.trim())
      return toast.error("MCM ID and password are required.");
    if (form.password.length < 8)
      return toast.error("Password must be at least 8 characters.");
    if (users.some((u) => u.username.toLowerCase() === form.username.trim().toLowerCase()))
      return toast.error("That MCM ID already exists.");
    setBusy(true);
    try {
      await rpcOr(
        "mcm_create_user",
        {
          p_username: form.username.trim(),
          p_password: form.password,
          p_full_name: form.full_name.trim() || null,
          p_role: form.role,
        },
        () =>
          sbInsert("mcm_users", {
            username: form.username.trim(),
            full_name: form.full_name.trim() || null,
            password: form.password,
            role: form.role,
          }),
      );
      toast.success(`User "${form.username.trim()}" added`);
      setForm({ username: "", full_name: "", password: "", role: "staff" });
      load();
    } catch (e) {
      toast.error("Could not add user: " + (e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const removeUser = async (u: AdminUser) => {
    if (u.username === currentUsername) return toast.error("You cannot remove your own account.");
    if (!window.confirm(`Remove user "${u.username}"? This cannot be undone.`)) return;
    try {
      await rpcOr("mcm_delete_user", { p_id: u.id }, () => sbDelete(`mcm_users?id=eq.${u.id}`));
      setUsers((list) => list.filter((x) => x.id !== u.id));
      toast.success("User removed");
    } catch (e) {
      toast.error("Could not remove user: " + (e as Error).message);
    }
  };

  const setRole = async (u: AdminUser, role: string) => {
    try {
      await rpcOr("mcm_set_role", { p_id: u.id, p_role: role }, () =>
        sbPatch(`mcm_users?id=eq.${u.id}`, { role }),
      );
      setUsers((list) => list.map((x) => (x.id === u.id ? { ...x, role } : x)));
      toast.success(`${u.username} is now ${role}`);
    } catch (e) {
      toast.error("Could not update role: " + (e as Error).message);
    }
  };

  return (
    <div className="space-y-6">
      <Panel title="Add a user" icon={<Plus className="size-4" />}>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <div>
            <FieldLabel>MCM ID</FieldLabel>
            <TextField
              value={form.username}
              placeholder="e.g. mcm023"
              onChange={(e) => setForm((f) => ({ ...f, username: e.target.value }))}
            />
          </div>
          <div>
            <FieldLabel>Full name</FieldLabel>
            <TextField
              value={form.full_name}
              placeholder="e.g. Ahmad Bin Ali"
              onChange={(e) => setForm((f) => ({ ...f, full_name: e.target.value }))}
            />
          </div>
          <div>
            <FieldLabel>Temporary password</FieldLabel>
            <TextField
              type="text"
              value={form.password}
              onChange={(e) => setForm((f) => ({ ...f, password: e.target.value }))}
            />
          </div>
          <div>
            <FieldLabel>Role</FieldLabel>
            <SelectField
              value={form.role}
              onChange={(e) => setForm((f) => ({ ...f, role: e.target.value }))}
            >
              <option value="staff">staff</option>
              <option value="admin">admin</option>
            </SelectField>
          </div>
        </div>
        <Button className="mt-5" onClick={addUser} disabled={busy}>
          <Plus className="size-4" /> {busy ? "Adding…" : "Add user"}
        </Button>
      </Panel>

      <Panel
        title="Staff accounts"
        icon={<Users className="size-4" />}
        action={<Pill tone="muted">{users.length} users</Pill>}
      >
        {loading && <p className="text-sm text-muted-foreground">Loading…</p>}
        <div className="space-y-2.5">
          {users.map((u) => (
            <div
              key={u.id}
              className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 rounded-2xl border border-border/70 bg-secondary/30 px-4 py-3"
            >
              <div className="min-w-0">
                <div className="truncate text-sm font-bold">{u.full_name || u.username}</div>
                <div className="truncate text-xs text-muted-foreground">MCM ID: {u.username}</div>
              </div>
              <div className="flex shrink-0 items-center gap-2">
                <SelectField
                  value={u.role || "staff"}
                  onChange={(e) => setRole(u, e.target.value)}
                  className="w-28 py-1.5 text-xs"
                >
                  <option value="staff">staff</option>
                  <option value="admin">admin</option>
                </SelectField>
                <button
                  onClick={() => removeUser(u)}
                  aria-label={`Remove ${u.username}`}
                  className="rounded-lg p-2 text-destructive/70 transition-colors hover:bg-destructive/10 hover:text-destructive"
                >
                  <Trash2 className="size-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </Panel>
    </div>
  );
}

/* ─── Prices ─────────────────────────────────────────────────────── */

function PricesTab() {
  const [rows, setRows] = useState<Service[]>([]);
  const [loading, setLoading] = useState(true);
  const [dirty, setDirty] = useState<Record<string, boolean>>({});
  const [query, setQuery] = useState("");
  const [draft, setDraft] = useState({ description: "", unit_price: "" });

  const load = () => {
    setLoading(true);
    sbGet<Service[]>("services?select=*&order=id")
      .then((d) => setRows(Array.isArray(d) ? d : []))
      .catch(() => toast.error("Could not load the price list."))
      .finally(() => setLoading(false));
  };

  useEffect(load, []);

  const filtered = useMemo(
    () => rows.filter((r) => r.description.toLowerCase().includes(query.toLowerCase())),
    [rows, query],
  );

  const edit = (id: number, patch: Partial<Service>) => {
    setRows((list) => list.map((r) => (r.id === id ? { ...r, ...patch } : r)));
    setDirty((d) => ({ ...d, [id]: true }));
  };

  const save = async (row: Service) => {
    try {
      await sbPatch(`services?id=eq.${row.id}`, {
        description: row.description,
        unit_price: Number(row.unit_price) || 0,
      });
      setDirty((d) => ({ ...d, [row.id]: false }));
      toast.success("Price updated");
    } catch (e) {
      toast.error("Update failed: " + (e as Error).message);
    }
  };

  const add = async () => {
    if (!draft.description.trim()) return toast.error("Enter a service description.");
    try {
      await sbInsert("services", {
        description: draft.description.trim(),
        unit_price: Number(draft.unit_price) || 0,
      });
      setDraft({ description: "", unit_price: "" });
      toast.success("Service added");
      load();
    } catch (e) {
      toast.error("Could not add service: " + (e as Error).message);
    }
  };

  const remove = async (row: Service) => {
    if (!window.confirm(`Remove "${row.description}" from the price list?`)) return;
    try {
      await sbDelete(`services?id=eq.${row.id}`);
      setRows((list) => list.filter((r) => r.id !== row.id));
      toast.success("Service removed");
    } catch (e) {
      toast.error("Could not remove: " + (e as Error).message);
    }
  };

  return (
    <div className="space-y-6">
      <Panel title="Add a service" icon={<Plus className="size-4" />}>
        <div className="grid gap-4 sm:grid-cols-[minmax(0,1fr)_180px]">
          <div>
            <FieldLabel>Description</FieldLabel>
            <TextField
              value={draft.description}
              placeholder="e.g. Weighing Scale — Capacity ≤ 10 kg"
              onChange={(e) => setDraft((d) => ({ ...d, description: e.target.value }))}
            />
          </div>
          <div>
            <FieldLabel>Unit price (RM)</FieldLabel>
            <TextField
              type="number"
              step="0.01"
              className="text-right"
              value={draft.unit_price}
              onChange={(e) => setDraft((d) => ({ ...d, unit_price: e.target.value }))}
            />
          </div>
        </div>
        <Button className="mt-5" onClick={add}>
          <Plus className="size-4" /> Add to price list
        </Button>
      </Panel>

      <Panel
        title="Calibration price list"
        description="Price List MCM Calibration Lab — May 2025"
        icon={<Tags className="size-4" />}
        action={
          <div className="flex items-center gap-2">
            <Pill tone="muted">{rows.length} items</Pill>
            <button
              onClick={load}
              aria-label="Reload"
              className="rounded-lg p-2 text-muted-foreground hover:bg-secondary hover:text-foreground"
            >
              <RefreshCw className="size-4" />
            </button>
          </div>
        }
      >
        <div className="relative mb-4">
          <Search className="absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" />
          <TextField
            className="pl-9"
            placeholder="Search services…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </div>

        {loading && <p className="text-sm text-muted-foreground">Loading…</p>}

        <div className="space-y-2.5">
          {filtered.map((row) => (
            <div
              key={row.id}
              className="grid gap-2.5 rounded-2xl border border-border/70 bg-secondary/30 p-3 sm:grid-cols-[minmax(0,1fr)_140px_auto] sm:items-center"
            >
              <TextField
                value={row.description}
                onChange={(e) => edit(row.id, { description: e.target.value })}
              />
              <TextField
                type="number"
                step="0.01"
                className="text-right"
                value={row.unit_price}
                onChange={(e) => edit(row.id, { unit_price: Number(e.target.value) })}
              />
              <div className="flex items-center justify-end gap-1.5">
                <Button
                  size="sm"
                  variant={dirty[row.id] ? "default" : "outline"}
                  onClick={() => save(row)}
                >
                  <Save className="size-4" />
                  <span className="hidden sm:inline">Save</span>
                </Button>
                <button
                  onClick={() => remove(row)}
                  aria-label="Remove service"
                  className="rounded-lg p-2 text-destructive/70 transition-colors hover:bg-destructive/10 hover:text-destructive"
                >
                  <Trash2 className="size-4" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {!loading && rows.length > 0 && (
          <p className="mt-4 text-xs text-muted-foreground">
            All prices in RM, subject to SST 8%. Outstation: RM {fmt(100)} for 40 km and below, RM
            2.50/km beyond that.
          </p>
        )}
      </Panel>
    </div>
  );
}

/* ─── Login history ──────────────────────────────────────────────── */

function HistoryTab() {
  const [logs, setLogs] = useState<LogRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    sbGet<LogRow[]>("login_history?select=*&order=logged_in_at.desc&limit=200")
      .then((data) => setLogs(Array.isArray(data) ? data : []))
      .catch(() => setError("Could not load login history."))
      .finally(() => setLoading(false));
  }, []);

  return (
    <Panel
      title="Sign-in log"
      icon={<History className="size-4" />}
      action={<Pill tone="muted">{logs.length} records</Pill>}
    >
      {loading && <p className="text-sm text-muted-foreground">Loading…</p>}
      {error && <p className="text-sm text-destructive">{error}</p>}
      {!loading && !error && logs.length === 0 && (
        <p className="text-sm text-muted-foreground">No login history yet.</p>
      )}

      {/* Mobile: cards. Desktop: table. */}
      <div className="space-y-2.5 sm:hidden">
        {logs.map((log) => (
          <div
            key={log.id}
            className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 rounded-2xl border border-border/70 bg-secondary/30 px-4 py-3"
          >
            <div className="min-w-0">
              <div className="truncate text-sm font-bold">{log.full_name || log.username}</div>
              <div className="truncate text-xs text-muted-foreground">
                {new Date(log.logged_in_at).toLocaleString("en-MY", {
                  dateStyle: "medium",
                  timeStyle: "short",
                })}
              </div>
            </div>
            <Pill tone={log.role === "admin" ? "brand" : "muted"}>{log.role}</Pill>
          </div>
        ))}
      </div>

      {logs.length > 0 && (
        <div className="hidden overflow-x-auto sm:block">
          <table className="w-full min-w-[640px] border-collapse text-sm">
            <thead>
              <tr className="text-[10px] tracking-[0.1em] text-muted-foreground uppercase">
                {["#", "MCM ID", "Full name", "Role", "Logged in at", "Status"].map((h) => (
                  <th key={h} className="border-b border-border px-3 py-2.5 text-left">
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {logs.map((log, i) => (
                <tr key={log.id} className="border-b border-border/50 hover:bg-secondary/50">
                  <td className="px-3 py-3 text-xs text-muted-foreground/70">{i + 1}</td>
                  <td className="px-3 py-3 font-bold text-primary">{log.username}</td>
                  <td className="px-3 py-3">{log.full_name || "—"}</td>
                  <td className="px-3 py-3">
                    <Pill tone={log.role === "admin" ? "brand" : "muted"}>{log.role}</Pill>
                  </td>
                  <td className="px-3 py-3 whitespace-nowrap text-muted-foreground">
                    {new Date(log.logged_in_at).toLocaleString("en-MY", {
                      dateStyle: "medium",
                      timeStyle: "short",
                    })}
                  </td>
                  <td className="px-3 py-3">
                    <Pill tone="success">Success</Pill>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </Panel>
  );
}

/* ─── Session rules ──────────────────────────────────────────────── */

function SessionTab() {
  const [settings, setSettings] = useState(DEFAULT_SETTINGS);

  useEffect(() => setSettings(readSettings()), []);

  const apply = () => {
    writeSettings({
      idleTimeoutMinutes: Math.max(0.5, Number(settings.idleTimeoutMinutes) || 2),
      idleWarningSeconds: Math.max(5, Number(settings.idleWarningSeconds) || 20),
      autosaveDrafts: settings.autosaveDrafts,
    });
    toast.success("Session settings saved");
  };

  return (
    <Panel
      title="Session & auto-logout"
      icon={<Timer className="size-4" />}
      description="Applies to this device"
    >
      <div className="grid gap-4 sm:grid-cols-2">
        <div>
          <FieldLabel>Auto-logout after inactivity (minutes)</FieldLabel>
          <TextField
            type="number"
            min="0.5"
            step="0.5"
            value={settings.idleTimeoutMinutes}
            onChange={(e) =>
              setSettings((s) => ({ ...s, idleTimeoutMinutes: Number(e.target.value) }))
            }
          />
        </div>
        <div>
          <FieldLabel>Warning countdown (seconds)</FieldLabel>
          <TextField
            type="number"
            min="5"
            step="5"
            value={settings.idleWarningSeconds}
            onChange={(e) =>
              setSettings((s) => ({ ...s, idleWarningSeconds: Number(e.target.value) }))
            }
          />
        </div>
      </div>

      <label className="mt-5 flex w-fit cursor-pointer items-center gap-3 text-sm">
        <input
          type="checkbox"
          checked={settings.autosaveDrafts}
          onChange={(e) => setSettings((s) => ({ ...s, autosaveDrafts: e.target.checked }))}
          className="size-4 accent-[oklch(0.443_0.209_265.3)]"
        />
        Auto-save quotation &amp; service request drafts
      </label>

      <div className="mt-5 flex items-center gap-3">
        <Button onClick={apply}>
          <ShieldCheck className="size-4" /> Save settings
        </Button>
        <Pill tone="muted">Currently {settings.idleTimeoutMinutes} min</Pill>
      </div>
    </Panel>
  );
}
