import { CloudCheck, RotateCcw } from "lucide-react";

export function DraftBanner({
  savedAt,
  restored,
  onDiscard,
}: {
  savedAt: number | null;
  restored: boolean;
  onDiscard: () => void;
}) {
  if (!savedAt) return null;

  const time = new Date(savedAt).toLocaleTimeString("en-MY", {
    hour: "2-digit",
    minute: "2-digit",
  });

  return (
    <div className="no-print grid grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-3 rounded-2xl border border-border/70 bg-secondary/40 px-4 py-2.5">
      <CloudCheck className="size-4 shrink-0 text-primary" />
      <p className="min-w-0 truncate text-xs font-semibold text-muted-foreground">
        {restored ? "Draft restored" : "Draft auto-saved"} · {time}
      </p>
      <button
        onClick={onDiscard}
        className="flex shrink-0 items-center gap-1.5 rounded-lg px-2 py-1 text-xs font-bold text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
      >
        <RotateCcw className="size-3.5" /> Discard
      </button>
    </div>
  );
}
