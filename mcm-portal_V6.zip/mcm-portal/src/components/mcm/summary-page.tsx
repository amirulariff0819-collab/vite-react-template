import { useEffect, useMemo, useState } from "react";
import { Link } from "@tanstack/react-router";
import {
  Database,
  FileText,
  ClipboardList,
  RefreshCw,
  Search,
  Pencil,
  X,
} from "lucide-react";
import { PageHeading, Panel, Pill, TextField, SelectField } from "@/components/mcm/primitives";
import { fmt, sbGet } from "@/lib/mcm-api";
import { cn } from "@/lib/utils";

type QuoteRow = {
  id: number;
  quote_no?: string;
  client_name?: string;
  client_address?: string;
  subtotal?: number;
  discount?: number;
  sst_amount?: number;
  outstation_fee?: number;
  total?: number;
  created_at?: string;
};

type SrfRow = {
  id: number;
  applicant?: string;
  date?: string;
  tel?: string;
  attn?: string;
  calibration_method?: string;
  requested_by?: string;
  created_at?: string;
};

const dt = (v?: string) => (v ? new Date(v).toLocaleString("en-MY") : "—");

const QUOTE_FIELDS = [
  { key: "all", label: "All fields" },
  { key: "quote_no", label: "Quote #" },
  { key: "client_name", label: "Client" },
  { key: "client_address", label: "Address" },
  { key: "total", label: "Total (RM)" },
] as const;

const SRF_FIELDS = [
  { key: "all", label: "All fields" },
  { key: "id", label: "Ref" },
  { key: "applicant", label: "Applicant" },
  { key: "attn", label: "Attn" },
  { key: "calibration_method", label: "Method" },
  { key: "requested_by", label: "Requested by" },
] as const;

const matches = (row: Record<string, unknown>, keys: string[], q: string) =>
  keys.some((k) =>
    String(row[k] ?? "")
      .toLowerCase()
      .includes(q),
  );

export function SummaryPage() {
  const [tab, setTab] = useState<"quotations" | "requests">("quotations");
  const [quotes, setQuotes] = useState<QuoteRow[]>([]);
  const [reqs, setReqs] = useState<SrfRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");
  const [fieldKey, setFieldKey] = useState("all");

  const load = () => {
    setLoading(true);
    Promise.all([
      sbGet<QuoteRow[]>("quotations?select=*&order=id.desc&limit=200")
        .then((d) => setQuotes(Array.isArray(d) ? d : []))
        .catch(() => setQuotes([])),
      sbGet<SrfRow[]>("service_requests?select=*&order=id.desc&limit=200")
        .then((d) => setReqs(Array.isArray(d) ? d : []))
        .catch(() => setReqs([])),
    ]).finally(() => setLoading(false));
  };

  useEffect(load, []);

  // Reset the field filter when switching tabs — the field lists differ.
  const switchTab = (next: "quotations" | "requests") => {
    setTab(next);
    setFieldKey("all");
  };

  const fields = tab === "quotations" ? QUOTE_FIELDS : SRF_FIELDS;

  const filteredQuotes = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return quotes;
    const keys =
      fieldKey === "all"
        ? ["quote_no", "client_name", "client_address", "total"]
        : [fieldKey];
    return quotes.filter((r) => matches(r as unknown as Record<string, unknown>, keys, q));
  }, [quotes, query, fieldKey]);

  const filteredReqs = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return reqs;
    const keys =
      fieldKey === "all"
        ? ["id", "applicant", "attn", "calibration_method", "requested_by"]
        : [fieldKey];
    return reqs.filter((r) => matches(r as unknown as Record<string, unknown>, keys, q));
  }, [reqs, query, fieldKey]);

  const quotedValue = quotes.reduce((s, q) => s + (Number(q.total) || 0), 0);
  const sstValue = quotes.reduce((s, q) => s + (Number(q.sst_amount) || 0), 0);

  const stats = [
    { label: "Saved quotations", value: String(quotes.length), icon: FileText },
    { label: "Service requests", value: String(reqs.length), icon: ClipboardList },
    { label: "Total quoted value", value: `RM ${fmt(quotedValue)}`, icon: Database },
    { label: "Total SST 8%", value: `RM ${fmt(sstValue)}`, icon: Database },
  ];

  return (
    <div className="space-y-6">
      <PageHeading
        title="Summary"
        subtitle="History of every quotation and service request saved — tap any row to edit it"
      />

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((s) => (
          <div key={s.label} className="surface p-5">
            <span className="bg-secondary text-primary mb-4 flex size-10 items-center justify-center rounded-xl">
              <s.icon className="size-5" />
            </span>
            <div className="text-2xl font-extrabold tracking-tight">{s.value}</div>
            <div className="text-xs text-muted-foreground">{s.label}</div>
          </div>
        ))}
      </div>

      <div className="flex flex-wrap items-center gap-2">
        {(
          [
            ["quotations", `Quotations (${quotes.length})`],
            ["requests", `Service requests (${reqs.length})`],
          ] as const
        ).map(([key, label]) => (
          <button
            key={key}
            onClick={() => switchTab(key)}
            className={cn(
              "rounded-full px-4 py-2 text-xs font-bold tracking-wide transition-colors",
              tab === key
                ? "bg-primary text-primary-foreground"
                : "bg-secondary text-muted-foreground hover:text-foreground",
            )}
          >
            {label}
          </button>
        ))}
        <button
          onClick={load}
          className="ml-auto inline-flex items-center gap-1.5 rounded-full bg-secondary px-4 py-2 text-xs font-bold text-muted-foreground transition-colors hover:text-foreground"
        >
          <RefreshCw className={cn("size-3.5", loading && "animate-spin")} /> Refresh
        </button>
      </div>

      <div className="surface flex flex-col gap-3 p-4 sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" />
          <TextField
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={
              tab === "quotations"
                ? "Search quote #, client, address…"
                : "Search applicant, attn, method…"
            }
            className="pr-9 pl-10"
          />
          {query && (
            <button
              type="button"
              onClick={() => setQuery("")}
              aria-label="Clear search"
              className="absolute top-1/2 right-3 -translate-y-1/2 text-muted-foreground hover:text-foreground"
            >
              <X className="size-4" />
            </button>
          )}
        </div>
        <SelectField
          value={fieldKey}
          onChange={(e) => setFieldKey(e.target.value)}
          className="sm:w-52"
          aria-label="Filter by field"
        >
          {fields.map((f) => (
            <option key={f.key} value={f.key}>
              {f.label}
            </option>
          ))}
        </SelectField>
      </div>

      {tab === "quotations" ? (
        <Panel
          title="Quotation history"
          icon={<FileText className="size-4" />}
          action={<Pill>{filteredQuotes.length} records</Pill>}
        >
          <div className="overflow-x-auto">
            <table className="w-full min-w-[780px] text-sm">
              <thead>
                <tr className="border-b border-border text-[11px] tracking-widest text-muted-foreground uppercase">
                  <th className="py-2.5 text-left">Quote #</th>
                  <th className="py-2.5 text-left">Client</th>
                  <th className="py-2.5 text-right">Subtotal</th>
                  <th className="py-2.5 text-right">Discount</th>
                  <th className="py-2.5 text-right">SST 8%</th>
                  <th className="py-2.5 text-right">Total (RM)</th>
                  <th className="py-2.5 text-right">Saved</th>
                  <th className="py-2.5 text-right" />
                </tr>
              </thead>
              <tbody>
                {filteredQuotes.map((q) => (
                  <tr
                    key={q.id}
                    className="border-b border-border/60 transition-colors last:border-0 hover:bg-secondary/60"
                  >
                    <td className="py-3 font-bold text-primary">
                      <Link to="/quotation" search={{ edit: q.id }} className="hover:underline">
                        {q.quote_no || q.id}
                      </Link>
                    </td>
                    <td className="py-3">{q.client_name || "—"}</td>
                    <td className="py-3 text-right">{fmt(q.subtotal)}</td>
                    <td className="py-3 text-right">{fmt(q.discount)}</td>
                    <td className="py-3 text-right">{fmt(q.sst_amount)}</td>
                    <td className="py-3 text-right font-bold">{fmt(q.total)}</td>
                    <td className="py-3 text-right text-xs text-muted-foreground">
                      {dt(q.created_at)}
                    </td>
                    <td className="py-3 text-right">
                      <Link
                        to="/quotation"
                        search={{ edit: q.id }}
                        className="inline-flex items-center gap-1.5 rounded-full bg-secondary px-3 py-1.5 text-[11px] font-bold text-muted-foreground transition-colors hover:text-foreground"
                      >
                        <Pencil className="size-3.5" /> Edit
                      </Link>
                    </td>
                  </tr>
                ))}
                {!loading && filteredQuotes.length === 0 && (
                  <tr>
                    <td colSpan={8} className="py-8 text-center text-sm text-muted-foreground">
                      {quotes.length ? "No quotations match your search." : "No quotations saved yet."}
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </Panel>
      ) : (
        <Panel
          title="Service request history"
          icon={<ClipboardList className="size-4" />}
          action={<Pill>{filteredReqs.length} records</Pill>}
        >
          <div className="overflow-x-auto">
            <table className="w-full min-w-[780px] text-sm">
              <thead>
                <tr className="border-b border-border text-[11px] tracking-widest text-muted-foreground uppercase">
                  <th className="py-2.5 text-left">Ref</th>
                  <th className="py-2.5 text-left">Applicant</th>
                  <th className="py-2.5 text-left">Attn</th>
                  <th className="py-2.5 text-left">Method</th>
                  <th className="py-2.5 text-left">Requested by</th>
                  <th className="py-2.5 text-right">Saved</th>
                  <th className="py-2.5 text-right" />
                </tr>
              </thead>
              <tbody>
                {filteredReqs.map((r) => (
                  <tr
                    key={r.id}
                    className="border-b border-border/60 transition-colors last:border-0 hover:bg-secondary/60"
                  >
                    <td className="py-3 font-bold text-primary">
                      <Link
                        to="/service-request"
                        search={{ edit: r.id }}
                        className="hover:underline"
                      >
                        SRF-{r.id}
                      </Link>
                    </td>
                    <td className="py-3">{r.applicant || "—"}</td>
                    <td className="py-3">{r.attn || "—"}</td>
                    <td className="py-3">{r.calibration_method || "—"}</td>
                    <td className="py-3">{r.requested_by || "—"}</td>
                    <td className="py-3 text-right text-xs text-muted-foreground">
                      {dt(r.created_at || r.date)}
                    </td>
                    <td className="py-3 text-right">
                      <Link
                        to="/service-request"
                        search={{ edit: r.id }}
                        className="inline-flex items-center gap-1.5 rounded-full bg-secondary px-3 py-1.5 text-[11px] font-bold text-muted-foreground transition-colors hover:text-foreground"
                      >
                        <Pencil className="size-3.5" /> Edit
                      </Link>
                    </td>
                  </tr>
                ))}
                {!loading && filteredReqs.length === 0 && (
                  <tr>
                    <td colSpan={7} className="py-8 text-center text-sm text-muted-foreground">
                      {reqs.length
                        ? "No service requests match your search."
                        : "No service requests saved yet."}
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </Panel>
      )}
    </div>
  );
}
