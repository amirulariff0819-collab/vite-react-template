import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { FileText, ClipboardList, Receipt, TrendingUp, ArrowRight } from "lucide-react";
import { PageHeading, Panel } from "@/components/mcm/primitives";
import { fmt, sbGet } from "@/lib/mcm-api";
import { useAuth } from "@/lib/auth";

type Quote = {
  id: number;
  quote_no?: string;
  client_name?: string;
  total?: number;
  created_at?: string;
};

export function DashboardPage() {
  const { user } = useAuth();
  const [quotes, setQuotes] = useState<Quote[]>([]);
  const [requests, setRequests] = useState<number>(0);

  useEffect(() => {
    sbGet<Quote[]>("quotations?select=*&order=id.desc&limit=8")
      .then((d) => setQuotes(Array.isArray(d) ? d : []))
      .catch(() => {});
    sbGet<{ id: number }[]>("service_requests?select=id")
      .then((d) => setRequests(Array.isArray(d) ? d.length : 0))
      .catch(() => {});
  }, []);

  const totalValue = quotes.reduce((s, q) => s + (Number(q.total) || 0), 0);

  const stats = [
    { label: "Recent quotations", value: String(quotes.length), icon: FileText },
    { label: "Service requests", value: String(requests), icon: ClipboardList },
    { label: "Recent quoted value", value: `RM ${fmt(totalValue)}`, icon: Receipt },
    { label: "SST rate", value: "8%", icon: TrendingUp },
  ];

  return (
    <div className="space-y-6">
      <div className="bg-gradient-deep shadow-lift relative overflow-hidden rounded-3xl px-7 py-9 text-white">
        <div className="absolute -top-24 -right-16 size-72 rounded-full bg-primary/40 blur-3xl" />
        <div className="relative">
          
          <h1 className="mt-4 text-3xl font-extrabold tracking-tight sm:text-4xl">
            Welcome back, {user?.full_name || user?.username}
          </h1>
          <p className="mt-2 max-w-xl text-sm text-white/70">
            Generate calibration quotations, submit service requests and manage your MCM account —
            all in one place.
          </p>
          <div className="mt-6 flex flex-wrap gap-3">
            <Link
              to="/quotation"
              className="inline-flex items-center gap-2 rounded-xl bg-white px-5 py-2.5 text-sm font-bold text-[oklch(0.199_0.059_268.9)] transition-transform hover:-translate-y-0.5"
            >
              New quotation <ArrowRight className="size-4" />
            </Link>
            <Link
              to="/service-request"
              className="inline-flex items-center gap-2 rounded-xl border border-white/25 px-5 py-2.5 text-sm font-bold text-white transition-colors hover:bg-white/10"
            >
              New service request
            </Link>
          </div>
        </div>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((s) => (
          <div key={s.label} className="surface p-5">
            <span className="bg-primary/10 text-primary flex size-10 items-center justify-center rounded-xl">
              <s.icon className="size-5" />
            </span>
            <p className="mt-4 text-2xl font-extrabold tracking-tight">{s.value}</p>
            <p className="text-xs text-muted-foreground">{s.label}</p>
          </div>
        ))}
      </div>

      <PageHeading title="Latest quotations" />
      <Panel title="Recent activity" icon={<FileText className="size-4" />}>
        {quotes.length === 0 ? (
          <p className="text-sm text-muted-foreground">
            No quotations yet — create your first one from the Quotation page.
          </p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[520px] text-sm">
              <thead>
                <tr className="text-[10px] tracking-[0.1em] text-muted-foreground uppercase">
                  {["Quote #", "Client", "Total (RM)"].map((h, i) => (
                    <th
                      key={h}
                      className={`border-b border-border px-3 py-2.5 ${i === 2 ? "text-right" : "text-left"}`}
                    >
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {quotes.map((q) => (
                  <tr key={q.id} className="border-b border-border/50 hover:bg-secondary/50">
                    <td className="px-3 py-3 font-bold text-primary">{q.quote_no || q.id}</td>
                    <td className="px-3 py-3">{q.client_name || "—"}</td>
                    <td className="px-3 py-3 text-right font-semibold">{fmt(q.total)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Panel>
    </div>
  );
}
