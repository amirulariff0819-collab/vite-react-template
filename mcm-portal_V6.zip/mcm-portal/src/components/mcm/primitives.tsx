import { cn } from "@/lib/utils";
import type { ReactNode } from "react";

export function FieldLabel({ children }: { children: ReactNode }) {
  return (
    <label className="mb-1.5 block text-[11px] font-semibold tracking-[0.1em] text-muted-foreground uppercase">
      {children}
    </label>
  );
}

const control =
  "w-full rounded-lg border border-input bg-background/60 px-3.5 py-2.5 text-sm text-foreground outline-none transition-all placeholder:text-muted-foreground/70 focus:border-primary focus:bg-card focus:ring-4 focus:ring-primary/12 disabled:opacity-60";

export function TextField({ className, ...props }: React.ComponentProps<"input">) {
  return <input {...props} className={cn(control, className)} />;
}

export function AreaField({ className, ...props }: React.ComponentProps<"textarea">) {
  return <textarea {...props} className={cn(control, "min-h-24 resize-y", className)} />;
}

export function SelectField({ className, children, ...props }: React.ComponentProps<"select">) {
  return (
    <select {...props} className={cn(control, "cursor-pointer appearance-none pr-9", className)}>
      {children}
    </select>
  );
}

export function Panel({
  children,
  className,
  title,
  icon,
  action,
  description,
}: {
  children: ReactNode;
  className?: string;
  title?: string;
  icon?: ReactNode;
  action?: ReactNode;
  description?: string;
}) {
  return (
    <section className={cn("surface overflow-hidden", className)}>
      {title && (
        <header className="flex items-center gap-3 border-b border-border/70 px-6 py-4">
          {icon && (
            <span className="bg-gradient-brand text-primary-foreground shadow-lift flex size-9 items-center justify-center rounded-xl">
              {icon}
            </span>
          )}
          <div className="min-w-0">
            <h3 className="truncate text-sm font-bold tracking-tight">{title}</h3>
            {description && (
              <p className="truncate text-xs text-muted-foreground">{description}</p>
            )}
          </div>
          {action && <div className="ml-auto">{action}</div>}
        </header>
      )}
      <div className="p-6">{children}</div>
    </section>
  );
}

export function Pill({
  children,
  tone = "brand",
}: {
  children: ReactNode;
  tone?: "brand" | "success" | "warning" | "danger" | "muted";
}) {
  const tones = {
    brand: "bg-primary/10 text-primary ring-primary/20",
    success: "bg-success/12 text-success ring-success/25",
    warning: "bg-warning/15 text-warning-foreground ring-warning/30",
    danger: "bg-destructive/10 text-destructive ring-destructive/20",
    muted: "bg-muted text-muted-foreground ring-border",
  } as const;
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-semibold tracking-wide ring-1 ring-inset",
        tones[tone],
      )}
    >
      {children}
    </span>
  );
}

export function PageHeading({ title, subtitle }: { title: string; subtitle?: string }) {
  return (
    <div className="mb-7">
      <h1 className="text-2xl font-extrabold tracking-tight sm:text-3xl">{title}</h1>
      {subtitle && <p className="mt-1 text-sm text-muted-foreground">{subtitle}</p>}
    </div>
  );
}
