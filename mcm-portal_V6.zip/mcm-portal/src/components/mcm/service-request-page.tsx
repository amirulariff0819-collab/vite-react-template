import { useEffect, useState, type SetStateAction } from "react";
import { useSearch } from "@tanstack/react-router";
import { useDraft } from "@/lib/use-draft";
import { DraftBanner } from "@/components/mcm/draft-banner";

import { ClipboardList, Package, Plus, Trash2, PenLine, Printer, Boxes } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Panel,
  FieldLabel,
  TextField,
  AreaField,
  Pill,
  PageHeading,
} from "@/components/mcm/primitives";
import { SignaturePad } from "@/components/mcm/signature-pad";
import { DocumentPreview } from "@/components/mcm/docs/document-preview";
import { SrfDocument } from "@/components/mcm/docs/srf-document";
import { sbGet, sbInsert, sbPatch, today } from "@/lib/mcm-api";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

type Item = {
  _id: number;
  type: string;
  manufacturer: string;
  modelNo: string;
  serialNo: string;
  qty: string;
  capacity: string;
  range: string;
  calibrationInterval: string;
};

const emptyItem = (): Item => ({
  _id: Date.now() + Math.random(),
  type: "",
  manufacturer: "",
  modelNo: "",
  serialNo: "",
  qty: "",
  capacity: "",
  range: "",
  calibrationInterval: "",
});

const LEFT_FIELDS = [
  { key: "type", label: "Type of item" },
  { key: "manufacturer", label: "Manufacturer" },
  { key: "modelNo", label: "Model no." },
  { key: "serialNo", label: "Serial no." },
] as const;

const RIGHT_FIELDS = [
  { key: "qty", label: "Quantity" },
  { key: "capacity", label: "Capacity" },
  { key: "range", label: "Range" },
  { key: "calibrationInterval", label: "Calibration interval" },
] as const;

type SrfDraft = {
  general: {
    applicant: string;
    date: string;
    jobNo: string;
    shippingAddress: string;
    billingAddress: string;
    tel: string;
    attn: string;
  };
  items: Item[];
  calibrationMethod: string;
  othersNote: string;
  accessories: string[];
  statedDueDate: boolean;
  requestedBy: { name: string; position: string };
  signature: string | null;
};

const emptySrfDraft = (): SrfDraft => ({
  general: {
    applicant: "",
    date: today(),
    jobNo: "",
    shippingAddress: "",
    billingAddress: "",
    tel: "",
    attn: "",
  },
  items: [emptyItem(), emptyItem()],
  calibrationMethod: "laboratory",
  othersNote: "",
  accessories: ["", "", "", ""],
  statedDueDate: false,
  requestedBy: { name: "", position: "" },
  signature: null,
});

export function ServiceRequestPage() {
  const {
    state: draft,
    setState: setDraft,
    savedAt,
    restored,
    clear: clearDraft,
  } = useDraft<SrfDraft>("service-request", emptySrfDraft());

  const field = <K extends keyof SrfDraft>(k: K) => {
    return (update: SetStateAction<SrfDraft[K]>) =>
      setDraft((d) => ({
        ...d,
        [k]:
          typeof update === "function"
            ? (update as (prev: SrfDraft[K]) => SrfDraft[K])(d[k])
            : update,
      }));
  };

  const {
    general,
    items,
    calibrationMethod,
    othersNote,
    accessories,
    statedDueDate,
    requestedBy,
    signature,
  } = draft;
  const setGeneral = field("general");
  const setItems = field("items");
  const setCalibrationMethod = field("calibrationMethod");
  const setOthersNote = field("othersNote");
  const setAccessories = field("accessories");
  const setStatedDueDate = field("statedDueDate");
  const setRequestedBy = field("requestedBy");
  const setSignature = field("signature");

  const [showDoc, setShowDoc] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const { edit: editId } = useSearch({ from: "/service-request" });

  // Opening a saved request from the Summary page loads it for editing.
  useEffect(() => {
    if (!editId) return;
    sbGet<Record<string, unknown>[]>(`service_requests?id=eq.${editId}&select=*&limit=1`)
      .then((rows) => {
        const row = rows?.[0];
        if (!row) {
          toast.error("Service request not found");
          return;
        }
        const savedItems = Array.isArray(row.items) ? (row.items as Item[]) : [];
        const savedAccessories = Array.isArray(row.accessories)
          ? (row.accessories as string[])
          : null;
        const method = String(row.calibration_method ?? "laboratory");
        setDraft((d) => ({
          ...d,
          general: {
            ...d.general,
            applicant: String(row.applicant ?? ""),
            date: String(row.date ?? today()).slice(0, 10),
            shippingAddress: String(row.shipping_address ?? ""),
            billingAddress: String(row.billing_address ?? ""),
            tel: String(row.tel ?? ""),
            attn: String(row.attn ?? ""),
          },
          items: savedItems.length ? savedItems : d.items,
          calibrationMethod: method.startsWith("others") ? "others" : method,
          othersNote: method.startsWith("others") ? method.replace(/^others:\s*/, "") : "",
          accessories: savedAccessories ?? d.accessories,
          statedDueDate: Boolean(row.stated_due_date),
          requestedBy: { ...d.requestedBy, name: String(row.requested_by ?? "") },
        }));
        toast.success(`Editing service request SRF-${editId}`);
      })
      .catch((e: Error) => toast.error("Could not load request: " + e.message));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [editId]);


  const updateGeneral = (k: keyof typeof general, v: string) =>
    setGeneral((g) => ({ ...g, [k]: v }));
  const updateItem = (idx: number, k: keyof Item, v: string) =>
    setItems((its) => its.map((it, i) => (i === idx ? { ...it, [k]: v } : it)));

  const handleSubmit = async () => {
    try {
      const payload = {
        applicant: general.applicant,
        date: general.date,
        shipping_address: general.shippingAddress,
        billing_address: general.billingAddress,
        tel: general.tel,
        attn: general.attn,
        items,
        calibration_method:
          calibrationMethod === "others" ? `others: ${othersNote}` : calibrationMethod,
        accessories,
        stated_due_date: statedDueDate,
        requested_by: requestedBy.name,
      };
      if (editId) await sbPatch(`service_requests?id=eq.${editId}`, payload);
      else await sbInsert("service_requests", payload);
      setSubmitted(true);
      clearDraft();
      toast.success(editId ? "Service request updated" : "Service request submitted");
      setTimeout(() => setSubmitted(false), 4000);
    } catch (e) {
      toast.error("Submit failed: " + (e as Error).message);
    }
  };

  return (
    <div className="space-y-6">
      <PageHeading
        title="Service Request Form"
        subtitle="Submit calibration service requests with a digital signature"
      />

      <DraftBanner savedAt={savedAt} restored={restored} onDiscard={clearDraft} />


      <Panel title="General Information" icon={<ClipboardList className="size-4" />}>
        <div className="grid gap-4 sm:grid-cols-3">
          <div>
            <FieldLabel>Applicant / company name</FieldLabel>
            <TextField
              value={general.applicant}
              onChange={(e) => updateGeneral("applicant", e.target.value)}
            />
          </div>
          <div>
            <FieldLabel>Date</FieldLabel>
            <TextField
              type="date"
              value={general.date}
              onChange={(e) => updateGeneral("date", e.target.value)}
            />
          </div>
          <div>
            <FieldLabel>Job no.</FieldLabel>
            <TextField
              value={general.jobNo}
              placeholder="Assigned on receipt"
              onChange={(e) => updateGeneral("jobNo", e.target.value)}
            />
          </div>
        </div>
        <div className="mt-4 grid gap-4 sm:grid-cols-2">
          <div>
            <FieldLabel>Shipping address</FieldLabel>
            <AreaField
              value={general.shippingAddress}
              onChange={(e) => updateGeneral("shippingAddress", e.target.value)}
            />
          </div>
          <div>
            <FieldLabel>Billing address</FieldLabel>
            <AreaField
              value={general.billingAddress}
              onChange={(e) => updateGeneral("billingAddress", e.target.value)}
            />
          </div>
        </div>
        <div className="mt-4 grid gap-4 sm:grid-cols-2">
          <div>
            <FieldLabel>Tel</FieldLabel>
            <TextField value={general.tel} onChange={(e) => updateGeneral("tel", e.target.value)} />
          </div>
          <div>
            <FieldLabel>Attn</FieldLabel>
            <TextField
              value={general.attn}
              onChange={(e) => updateGeneral("attn", e.target.value)}
            />
          </div>
        </div>
      </Panel>

      <Panel
        title="Calibration Items"
        description="No limit — add as many items as needed"
        icon={<Package className="size-4" />}
        action={
          <div className="flex items-center gap-2">
            <Pill>
              {items.length} item{items.length !== 1 ? "s" : ""}
            </Pill>
            <Button size="sm" onClick={() => setItems((i) => [...i, emptyItem()])}>
              <Plus className="size-4" /> Add
            </Button>
          </div>
        }
      >
        <div
          className={cn(
            "space-y-4",
            items.length > 2 && "max-h-[560px] overflow-y-auto pr-1",
          )}
        >
          {items.map((item, idx) => (
            <div
              key={item._id}
              className="rounded-xl border border-border bg-secondary/40 p-5 ring-1 ring-transparent transition-shadow hover:ring-primary/15"
            >
              <div className="mb-4 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <span className="bg-gradient-brand flex size-7 items-center justify-center rounded-full text-xs font-extrabold text-primary-foreground">
                    {idx + 1}
                  </span>
                  <span className="text-xs font-bold tracking-[0.08em] uppercase">
                    Item {idx + 1}
                  </span>
                </div>
                {items.length > 1 && (
                  <button
                    onClick={() => setItems((i) => i.filter((_, i2) => i2 !== idx))}
                    className="flex items-center gap-1.5 rounded-lg border border-destructive/25 px-2.5 py-1.5 text-xs font-semibold text-destructive transition-colors hover:bg-destructive/10"
                  >
                    <Trash2 className="size-3.5" /> Remove
                  </button>
                )}
              </div>
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-3">
                  {LEFT_FIELDS.map((f) => (
                    <div key={f.key}>
                      <FieldLabel>{f.label}</FieldLabel>
                      <TextField
                        value={item[f.key]}
                        onChange={(e) => updateItem(idx, f.key, e.target.value)}
                      />
                    </div>
                  ))}
                </div>
                <div className="space-y-3">
                  {RIGHT_FIELDS.map((f) => (
                    <div key={f.key}>
                      <FieldLabel>{f.label}</FieldLabel>
                      <TextField
                        value={item[f.key]}
                        onChange={(e) => updateItem(idx, f.key, e.target.value)}
                      />
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
        <Button
          variant="outline"
          className="mt-4"
          onClick={() => setItems((i) => [...i, emptyItem()])}
        >
          <Plus className="size-4" /> Add another item
        </Button>
      </Panel>

      <div className="grid gap-6 lg:grid-cols-2">
        <Panel title="Calibration Method" icon={<ClipboardList className="size-4" />}>
          <div className="space-y-3">
            {[
              { val: "laboratory", label: "Laboratory standard calibration method" },
              { val: "others", label: "Others" },
            ].map((opt) => (
              <button
                key={opt.val}
                onClick={() => setCalibrationMethod(opt.val)}
                className={cn(
                  "flex w-full items-center gap-3 rounded-xl border px-4 py-3 text-left text-sm transition-all",
                  calibrationMethod === opt.val
                    ? "border-primary/40 bg-primary/8 font-semibold text-foreground"
                    : "border-border text-muted-foreground hover:bg-secondary",
                )}
              >
                <span
                  className={cn(
                    "flex size-4.5 items-center justify-center rounded-full border-2",
                    calibrationMethod === opt.val ? "border-primary" : "border-input",
                  )}
                >
                  {calibrationMethod === opt.val && (
                    <span className="size-2 rounded-full bg-primary" />
                  )}
                </span>
                {opt.label}
              </button>
            ))}
            {calibrationMethod === "others" && (
              <TextField
                placeholder="Specify method…"
                value={othersNote}
                onChange={(e) => setOthersNote(e.target.value)}
              />
            )}
          </div>
        </Panel>

        <Panel title="Accessories" icon={<Boxes className="size-4" />}>
          <div className="space-y-3">
            {accessories.map((a, i) => (
              <div key={i} className="flex items-center gap-3">
                <span className="w-4 text-xs text-muted-foreground">{i + 1}</span>
                <TextField
                  value={a}
                  placeholder={`Accessory ${i + 1}`}
                  onChange={(e) =>
                    setAccessories((prev) => prev.map((x, j) => (j === i ? e.target.value : x)))
                  }
                />
              </div>
            ))}
            <Button variant="outline" size="sm" onClick={() => setAccessories((a) => [...a, ""])}>
              <Plus className="size-4" /> Add accessory
            </Button>
          </div>
        </Panel>
      </div>

      <Panel title="Applicant's Request" icon={<ClipboardList className="size-4" />}>
        <button
          onClick={() => setStatedDueDate((d) => !d)}
          className={cn(
            "flex items-center gap-3 rounded-xl border px-4 py-3 text-sm transition-all",
            statedDueDate
              ? "border-primary/40 bg-primary/8 font-semibold"
              : "border-border text-muted-foreground hover:bg-secondary",
          )}
        >
          <span
            className={cn(
              "flex size-4.5 items-center justify-center rounded-[6px] border-2",
              statedDueDate ? "border-primary bg-primary" : "border-input",
            )}
          >
            {statedDueDate && (
              <svg width="10" height="10" viewBox="0 0 12 12">
                <path
                  d="M2 6l3 3 5-5"
                  stroke="white"
                  strokeWidth="2"
                  fill="none"
                  strokeLinecap="round"
                />
              </svg>
            )}
          </span>
          Stated due date on the items &amp; report
        </button>
      </Panel>

      <Panel title="Requested By — Digital Signature" icon={<PenLine className="size-4" />}>
        <div className="mb-5 grid gap-4 sm:grid-cols-2">
          <div>
            <FieldLabel>Full name</FieldLabel>
            <TextField
              value={requestedBy.name}
              onChange={(e) => setRequestedBy((r) => ({ ...r, name: e.target.value }))}
            />
          </div>
          <div>
            <FieldLabel>Position / title</FieldLabel>
            <TextField
              value={requestedBy.position}
              onChange={(e) => setRequestedBy((r) => ({ ...r, position: e.target.value }))}
            />
          </div>
        </div>
        <FieldLabel>Signature</FieldLabel>
        <SignaturePad onSave={(dataUrl) => setSignature(dataUrl)} />
        {signature && (
          <p className="mt-3">
            <Pill tone="success">✓ Signature captured</Pill>
          </p>
        )}
      </Panel>

      <div className="surface border-l-4 border-l-primary p-5 text-xs leading-relaxed text-muted-foreground">
        <strong className="text-foreground">Received by:</strong> Metrology Corporation Malaysia Sdn
        Bhd (Laboratory)
        <br />
        No. 3, Jalan 33/10A, Kawasan Perindustrian IKS, Mukim Batu, 68100 Kuala Lumpur
        <br />
        Form: FM02-SOP04, Rev B | 08.07.2021
      </div>

      <div className="no-print flex flex-wrap justify-end gap-3 pb-6">
        <Button variant="outline" onClick={() => setShowDoc(true)}>
          <Printer className="size-4" /> Generate SRF document
        </Button>
        <Button onClick={handleSubmit}>
          {submitted ? "✓ Submitted" : "Submit service request"}
        </Button>
      </div>

      <DocumentPreview
        open={showDoc}
        onClose={() => setShowDoc(false)}
        title="Service Request Form — generated document"
      >
        <SrfDocument
          data={{
            ...general,
            items,
            calibrationMethod,
            othersNote,
            accessories,
            statedDueDate,
            requestedByName: requestedBy.name,
            requestedByPosition: requestedBy.position,
            signature,
          }}
        />
      </DocumentPreview>
    </div>
  );
}
