import { type ReactNode, useEffect } from "react";
import { createPortal } from "react-dom";
import { Printer, X } from "lucide-react";
import { Button } from "@/components/ui/button";

export function DocumentPreview({
  open,
  onClose,
  title,
  children,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  children: ReactNode;
}) {
  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = prev;
    };
  }, [open]);

  if (!open || typeof document === "undefined") return null;

  return createPortal(
    <div className="fixed inset-0 z-[100] flex flex-col bg-[#3a4256]">
      <div className="no-print flex items-center justify-between gap-3 border-b border-white/10 bg-[#1a2036] px-5 py-3 text-white">
        <span className="text-sm font-bold tracking-wide">{title}</span>
        <div className="flex items-center gap-2">
          <Button size="sm" onClick={() => window.print()}>
            <Printer className="size-4" /> Print / Save as PDF
          </Button>
          <button
            type="button"
            onClick={onClose}
            className="inline-flex h-9 items-center gap-1.5 rounded-lg bg-card px-3.5 text-sm font-semibold text-foreground shadow-lift transition-colors hover:bg-secondary"
          >
            <X className="size-4" /> Close
          </button>
        </div>
      </div>

      <div className="doc-print-root flex-1 overflow-auto p-6">{children}</div>
    </div>,
    document.body,
  );
}
