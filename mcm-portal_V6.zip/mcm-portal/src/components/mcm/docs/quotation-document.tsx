import logoUrl from "@/assets/mcm-logo.png";
import ilacUrl from "@/assets/ilac-mra.png";
import sammUrl from "@/assets/samm.png";
import { fmt } from "@/lib/mcm-api";

export type QuoteLine = { description: string; qty: number; unitPrice: number };

export type QuotationData = {
  date: string;
  quoteNo: string;
  sstId: string;
  clientName: string;
  clientAddress: string;
  lines: QuoteLine[];
  outstationFee: number;
  subtotal: number;
  discount: number;
  sst: number;
  rounding: number;
  total: number;
  signature?: string;
  signName?: string;
  signPosition?: string;
};

const TERMS: string[] = [
  "Our quotation validity will be 30 days from the quotation date.",
  "Term of Payment: COD. Interest Rate 3% per month of the total amount due will be charged on overdue payments.",
  "Currency : MYR",
  "Completion date of in-house calibration services :\n(a) Normal Service : 7 Working Days.\n(b) Urgent Service : 4 - 6 Working Days inclusive 50% urgent rate from standard price.\n(c) Express Service : 1 - 3 Working Day inclusive 100% urgent rate from standard price.",
  "Please call to postpone on site calibration request within 24 hours in advance (Peninsular Malaysia only). Otherwise a minimum charge of RM 600.00 will be imposed once our personnel is at your premises.",
  "The customer is to provide technical personnel assistance during the calibration process for dismantling or assembling of parts/components as where and when required during an On-site calibration exercise. We shall not bear any responsibility for mishandling of your equipment if the damage is attributed to the customer's fault. The customer shall then set up the equipment after the calibration with the presence of the service provider to verify that the mentioned instrument or machine is working properly.",
  "Customer has to ensure that the equipment is under condition ready for calibration.",
  "Customer has to prepare sufficient substitution loads for the capacity of the weighing instrument to be calibrated.",
  "Customer has to accompany and escort our technical personnel during calibration period at your side.",
  "Site calibration schedule will be arrange upon order confirmation.",
  "Courier charges to be borne by customer.",
  "A charge of RM20.00 shall be imposed for reissuance of the Official calibration certificate.",
  "If you have any questions concerning this quotation, drop your email to mcmmasslab@gmail.com.",
];

function TotalRows({ data }: { data: QuotationData }) {
  const rows: [string, number, boolean][] = [
    ["Subtotal", data.subtotal, false],
    ["Discount", data.discount, false],
    ["SST 8%", data.sst, false],
    ["Rounding Adj.", data.rounding, false],
    ["Total", data.total, true],
  ];
  return (
    <>
      {rows.map(([label, value, strong], i) => (
        <tr key={label}>
          {i === 0 && (
            <td rowSpan={rows.length} style={{ width: "56%", verticalAlign: "top" }}>
              <div>We confirm &amp; take acceptance of the above offer</div>
              {data.signature ? (
                <img
                  src={data.signature}
                  alt="Authorised signature"
                  style={{ height: "56px", width: "auto", marginTop: "6px", display: "block" }}
                />
              ) : (
                <div style={{ height: "58px" }} />
              )}
              <div style={{ fontSize: "8pt" }}>
                ______________________________
                <br />
                (Company Stamp &amp; Authorised Signature)
              </div>
              <div style={{ marginTop: "8px" }}>
                Name : {data.signName ? data.signName : "____________________"}
              </div>
              <div style={{ marginTop: "4px" }}>
                Position : {data.signPosition ? data.signPosition : "_________________"}
              </div>
            </td>
          )}
          <td
            style={{
              textAlign: "right",
              fontWeight: 700,
              color: "#1f5fa8",
              background: strong ? "#cfe2f3" : "#fff",
            }}
          >
            {label}
          </td>
          <td
            style={{
              width: "34%",
              textAlign: "right",
              fontWeight: strong ? 700 : 400,
              background: strong ? "#cfe2f3" : "#eaf3fb",
            }}
          >
            <span style={{ float: "left", fontWeight: 700, color: "#1f5fa8" }}>RM</span>
            {fmt(value)}
          </td>
        </tr>
      ))}
    </>
  );
}


export function QuotationDocument({ data }: { data: QuotationData }) {
  const lines = [...data.lines];
  if (data.outstationFee > 0) {
    lines.push({
      description: "Outstation / travelling charges",
      qty: 1,
      unitPrice: data.outstationFee,
    });
  }
  const filler = Math.max(0, 10 - lines.length);

  return (
    <>
      {/* ---------- Page 1 ---------- */}
      <div className="doc-sheet">
        <table className="nb">
          <tbody>
            <tr>
              <td style={{ width: "56%", verticalAlign: "top" }}>
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: "10px",
                    flexWrap: "nowrap",
                  }}
                >
                  <img
                    src={logoUrl}
                    alt="Metrology Corporation Malaysia"
                    style={{ height: "44px", width: "auto", objectFit: "contain" }}
                  />
                  <img
                    src={ilacUrl}
                    alt="ILAC MRA"
                    style={{ height: "40px", width: "auto", objectFit: "contain" }}
                  />
                  <img
                    src={sammUrl}
                    alt="SAMM accreditation"
                    style={{ height: "40px", width: "auto", objectFit: "contain" }}
                  />
                </div>
                <div style={{ marginTop: "8px", fontSize: "8.5pt", lineHeight: 1.35 }}>
                  No.3, Jalan 33/10A, Kawasan Perindustrian IKS,
                  <br />
                  68100 Mukim Batu, Kuala Lumpur
                  <br />
                  Phone: (+60) 13-3969082
                  <br />
                  mcmmasslab@gmail.com
                </div>
              </td>
              <td style={{ verticalAlign: "top", textAlign: "right" }}>
                <div
                  style={{
                    fontSize: "22pt",
                    fontWeight: 700,
                    letterSpacing: "2px",
                    color: "#173a6b",
                  }}
                >
                  QUOTATION
                </div>
                <table className="nb" style={{ marginLeft: "auto", width: "78%" }}>
                  <tbody>
                    <tr>
                      <td style={{ textAlign: "right", color: "#1f5fa8", fontWeight: 700 }}>
                        Date :
                      </td>
                      <td style={{ textAlign: "right", paddingLeft: "8px" }}>{data.date}</td>
                    </tr>
                    <tr>
                      <td style={{ textAlign: "right", color: "#1f5fa8", fontWeight: 700 }}>
                        Quote :
                      </td>
                      <td style={{ textAlign: "right", paddingLeft: "8px" }}>{data.quoteNo}</td>
                    </tr>
                    <tr>
                      <td style={{ textAlign: "right", color: "#1f5fa8", fontWeight: 700 }}>
                        SST ID No. :
                      </td>
                      <td style={{ textAlign: "right", paddingLeft: "8px" }}>{data.sstId}</td>
                    </tr>
                  </tbody>
                </table>
              </td>
            </tr>
          </tbody>
        </table>

        <div style={{ marginTop: "10px" }}>
          <div
            style={{
              background: "#1f5fa8",
              color: "#fff",
              fontWeight: 700,
              padding: "3px 8px",
            }}
          >
            To:
          </div>
          <div style={{ fontWeight: 700, marginTop: "4px" }}>{data.clientName}</div>
          <div style={{ whiteSpace: "pre-wrap" }}>{data.clientAddress}</div>
        </div>

        <table className="quote-table" style={{ marginTop: "10px" }}>
          <thead>
            <tr>
              <th style={{ width: "34px" }}>No.</th>
              <th style={{ textAlign: "center" }}>Description</th>
              <th style={{ width: "62px" }}>Quantity</th>
              <th style={{ width: "82px" }}>Unit price</th>
              <th style={{ width: "92px" }}>Amount</th>
            </tr>
          </thead>
          <tbody>
            {lines.map((l, i) => (
              <tr key={i}>
                <td style={{ textAlign: "center" }}>{i + 1}</td>
                <td>{l.description}</td>
                <td style={{ textAlign: "center" }}>{l.qty}</td>
                <td style={{ textAlign: "right" }}>{fmt(l.unitPrice)}</td>
                <td style={{ textAlign: "right" }}>{fmt(l.qty * l.unitPrice)}</td>
              </tr>
            ))}
            {Array.from({ length: filler }).map((_, i) => (
              <tr key={`f${i}`}>
                <td style={{ height: "18px" }}>&nbsp;</td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
              </tr>
            ))}
          </tbody>
        </table>

        <table className="quote-foot" style={{ marginTop: "0" }}>
          <tbody>
            <TotalRows data={data} />
          </tbody>
        </table>


        <div style={{ marginTop: "auto", paddingTop: "10px", textAlign: "center", fontSize: "8pt" }}>
          Page 1 of 2
        </div>
      </div>


      {/* ---------- Page 2 ---------- */}
      <div className="doc-sheet">
        <div style={{ fontSize: "14pt", fontWeight: 700, marginBottom: "10px" }}>
          Terms and Conditions
        </div>
        <ol style={{ paddingLeft: "20px", margin: 0, listStyleType: "decimal" }}>
          {TERMS.map((t) => (
            <li key={t} style={{ marginBottom: "6px", whiteSpace: "pre-line", textAlign: "justify" }}>
              {t}
            </li>
          ))}
        </ol>
        <div style={{ marginTop: "auto", paddingTop: "10px", textAlign: "center", fontSize: "8pt" }}>
          Page 2 of 2
        </div>
      </div>
    </>
  );
}