import logoUrl from "@/assets/mcm-logo.png";

export type SrfItem = {
  type: string;
  manufacturer: string;
  modelNo: string;
  serialNo: string;
  qty: string;
  capacity: string;
  range: string;
  calibrationInterval: string;
};

export type SrfData = {
  applicant: string;
  date: string;
  jobNo: string;
  shippingAddress: string;
  billingAddress: string;
  tel: string;
  attn: string;
  items: SrfItem[];
  calibrationMethod: string;
  othersNote: string;
  accessories: string[];
  statedDueDate: boolean;
  requestedByName: string;
  requestedByPosition: string;
  signature: string | null;
};

const Box = ({ checked }: { checked: boolean }) => (
  <span
    style={{
      display: "inline-block",
      width: "10px",
      height: "10px",
      border: "1px solid #000",
      marginRight: "6px",
      textAlign: "center",
      lineHeight: "9px",
      fontSize: "8pt",
      fontWeight: 700,
    }}
  >
    {checked ? "X" : ""}
  </span>
);

export function SrfDocument({ data }: { data: SrfData }) {
  const items = data.items.length ? data.items : [];
  const rows = [...items];
  while (rows.length < 4) {
    rows.push({
      type: "",
      manufacturer: "",
      modelNo: "",
      serialNo: "",
      qty: "",
      capacity: "",
      range: "",
      calibrationInterval: "",
    });
  }
  const accessories = [...data.accessories];
  while (accessories.length < 4) accessories.push("");

  return (
    <div className="doc-sheet">
      {/* Header */}
      <table>
        <tbody>
          <tr>
            <td style={{ width: "42%", verticalAlign: "middle", padding: "6px 8px" }}>
              <img
                src={logoUrl}
                alt="Metrology Corporation Malaysia"
                style={{ width: "100%", maxWidth: "210px", objectFit: "contain" }}
              />
            </td>
            <td style={{ verticalAlign: "middle", padding: "6px 8px" }}>
              <div
                style={{
                  fontSize: "14pt",
                  fontWeight: 700,
                  textAlign: "center",
                  letterSpacing: "0.5px",
                }}
              >
                SERVICE REQUEST FORM
              </div>
              <div style={{ marginTop: "10px", fontSize: "10pt" }}>
                Job No. : <strong>{data.jobNo || "\u00a0"}</strong>
              </div>
              <div style={{ fontSize: "7.5pt", fontStyle: "italic" }}>
                * In Inquiry, please refer to this job number
              </div>
            </td>
          </tr>
        </tbody>
      </table>

      {/* Applicant */}
      <table style={{ marginTop: "6px" }}>
        <tbody>
          <tr>
            <td style={{ width: "62%" }}>
              Applicant : <strong>{data.applicant}</strong>
              <div style={{ fontSize: "7.5pt", fontStyle: "italic" }}>Name of Company</div>
            </td>
            <td>
              Date : <strong>{data.date}</strong>
            </td>
          </tr>
          <tr>
            <td style={{ height: "58px" }}>
              Shipping Address:
              <div style={{ whiteSpace: "pre-wrap" }}>{data.shippingAddress}</div>
            </td>
            <td>
              Billing Address:
              <div style={{ whiteSpace: "pre-wrap" }}>{data.billingAddress}</div>
            </td>
          </tr>
          <tr>
            <td>Tel: {data.tel}</td>
            <td>Attn: {data.attn}</td>
          </tr>
        </tbody>
      </table>

      {/* Items */}
      <table style={{ marginTop: "6px" }}>
        <thead>
          <tr>
            <th style={{ width: "22px" }}></th>
            <th style={{ textAlign: "left" }}>Type / Manufacturer / Model / Serial No.</th>
            <th style={{ textAlign: "left", width: "44%" }}>
              Quantity | Capacity | Range | Cal. Interval
            </th>
          </tr>
        </thead>
        <tbody>
          {rows.map((it, i) => (
            <tr key={i}>
              <td style={{ textAlign: "center" }}>{i + 1}</td>
              <td>
                <table className="nb">
                  <tbody>
                    <tr>
                      <td style={{ width: "38%" }}>Type of item</td>
                      <td>: {it.type}</td>
                    </tr>
                    <tr>
                      <td>Manufacturer</td>
                      <td>: {it.manufacturer}</td>
                    </tr>
                    <tr>
                      <td>Model No.</td>
                      <td>: {it.modelNo}</td>
                    </tr>
                    <tr>
                      <td>Serial No.</td>
                      <td>: {it.serialNo}</td>
                    </tr>
                  </tbody>
                </table>
                <div style={{ fontSize: "7pt", fontStyle: "italic" }}>
                  (Indicator, platform, etc)
                </div>
              </td>
              <td>
                <table className="nb">
                  <tbody>
                    <tr>
                      <td style={{ width: "48%" }}>Quantity</td>
                      <td>: {it.qty}</td>
                    </tr>
                    <tr>
                      <td>Capacity</td>
                      <td>: {it.capacity}</td>
                    </tr>
                    <tr>
                      <td>Range</td>
                      <td>: {it.range}</td>
                    </tr>
                    <tr>
                      <td>Calibration Interval</td>
                      <td>: {it.calibrationInterval}</td>
                    </tr>
                  </tbody>
                </table>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Method & accessories */}
      <table style={{ marginTop: "6px" }}>
        <thead>
          <tr>
            <th style={{ textAlign: "left", width: "56%" }}>Calibration Method</th>
            <th style={{ textAlign: "left" }}>Accessories</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>
              <div>
                <Box checked={data.calibrationMethod === "laboratory"} />
                Laboratory standard calibration method
              </div>
              <div style={{ marginTop: "6px" }}>
                <Box checked={data.calibrationMethod === "others"} />
                Others {data.calibrationMethod === "others" ? `: ${data.othersNote}` : ""}
              </div>
            </td>
            <td>
              {accessories.map((a, i) => (
                <div key={i}>
                  {i + 1}) {a}
                </div>
              ))}
            </td>
          </tr>
        </tbody>
      </table>

      {/* Request & signature */}
      <table style={{ marginTop: "6px" }}>
        <thead>
          <tr>
            <th style={{ textAlign: "left", width: "56%" }}>Applicant's Request</th>
            <th style={{ textAlign: "left" }}>Requested by:</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td style={{ height: "90px" }}>
              <div style={{ marginTop: "16px" }}>
                <Box checked={data.statedDueDate} />
                Stated due date on the items &amp; Report
              </div>
            </td>
            <td>
              <div style={{ height: "52px" }}>
                Signature :
                {data.signature ? (
                  <img
                    src={data.signature}
                    alt="Signature"
                    style={{ display: "block", height: "42px", objectFit: "contain" }}
                  />
                ) : null}
              </div>
              <div>Name : {data.requestedByName}</div>
              {data.requestedByPosition ? <div>Position : {data.requestedByPosition}</div> : null}
            </td>
          </tr>
        </tbody>
      </table>

      {/* Footer */}
      <table style={{ marginTop: "6px" }}>
        <tbody>
          <tr>
            <td style={{ width: "56%" }}>
              <strong>Received by:</strong>
              <div>Metrology Corporation Malaysia Sdn Bhd (Laboratory)</div>
              <div>No. 3, Jalan 33/10A, Kawasan Perindustrian IKS</div>
              <div>Mukim Batu, 68100 Kuala Lumpur</div>
            </td>
            <td style={{ height: "70px" }}>Acceptance sign/date of service request</td>
          </tr>
        </tbody>
      </table>

      <div style={{ marginTop: "6px", fontSize: "7.5pt", textAlign: "center" }}>
        Service Request Form, FM02-SOP04, Rev B | 08.07.2021
      </div>
    </div>
  );
}