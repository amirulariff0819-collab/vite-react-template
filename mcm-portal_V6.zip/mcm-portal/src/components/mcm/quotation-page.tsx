import { useEffect, useMemo, useState, type SetStateAction } from "react";
import { useSearch } from "@tanstack/react-router";
import { useDraft } from "@/lib/use-draft";
import { DraftBanner } from "@/components/mcm/draft-banner";


import { Plus, Trash2, FileText, Building2, Route, Receipt, ScrollText, Printer } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Panel, FieldLabel, TextField, SelectField, Pill, PageHeading } from "@/components/mcm/primitives";
import { SignaturePad } from "@/components/mcm/signature-pad";
import { DocumentPreview } from "@/components/mcm/docs/document-preview";
import { QuotationDocument } from "@/components/mcm/docs/quotation-document";
import {
  FALLBACK_SERVICES,
  fmt,
  sbGet,
  sbInsert,
  sbPatch,
  today,
  type Service,
} from "@/lib/mcm-api";
import { toast } from "sonner";

type Line = {
  id: number;
  serviceId: string;
  description: string;
  qty: number | string;
  unitPrice: number | string;
};

const emptyLine = (): Line => ({
  id: Date.now() + Math.random(),
  serviceId: "",
  description: "",
  qty: 1,
  unitPrice: 0,
});

const TERMS = [
  "Quotation validity: 30 days from quotation date.",
  "Payment terms: COD. Interest rate 3% per month on overdue payments.",
  "Currency: MYR.",
  "Normal Service: 7 Working Days. Urgent Service: 4–6 WD + 50% surcharge. Express Service: 1–3 WD + 100% surcharge.",
  "Cancellation of on-site calibration must be made at least 24 hours in advance (Peninsular Malaysia). Otherwise a minimum charge of RM 600.00 applies.",
  "Customer must provide technical assistance during calibration for dismantling/assembly.",
  "Customer must ensure equipment is ready for calibration.",
  "Courier charges to be borne by customer.",
  "A charge of RM 20.00 applies for reissuance of the Official Calibration Certificate.",
];

type QuotationDraft = {
  header: {
    date: string;
    quoteNo: string;
    sstId: string;
    clientName: string;
    clientAddress: string;
  };
  lines: Line[];
  outstation: { enabled: boolean; distance: string };
  discount: string | number;
  signOn: boolean;
  sign: { dataUrl: string; name: string; position: string };
};

const emptyDraft = (): QuotationDraft => ({
  header: {
    date: today(),
    quoteNo: "00320",
    sstId: "W10-1810-32000206",
    clientName: "",
    clientAddress: "",
  },
  lines: [emptyLine()],
  outstation: { enabled: false, distance: "" },
  discount: 0,
  signOn: false,
  sign: { dataUrl: "", name: "", position: "" },
});

export function QuotationPage() {
  const {
    state: draft,
    setState: setDraft,
    savedAt,
    restored,
    clear: clearDraft,
  } = useDraft<QuotationDraft>("quotation", emptyDraft());

  const field = <K extends keyof QuotationDraft>(k: K) => {
    return (update: SetStateAction<QuotationDraft[K]>) =>
      setDraft((d) => ({
        ...d,
        [k]:
          typeof update === "function"
            ? (update as (prev: QuotationDraft[K]) => QuotationDraft[K])(d[k])
            : update,
      }));
  };

  const { header, lines, outstation, discount, signOn, sign } = draft;
  const setHeader = field("header");
  const setLines = field("lines");
  const setOutstation = field("outstation");
  const setDiscount = field("discount");
  const setSignOn = field("signOn");
  const setSign = field("sign");

  const { edit: editId } = useSearch({ from: "/quotation" });

  const [loading, setLoading] = useState(false);
  const [saved, setSaved] = useState(false);
  const [showDoc, setShowDoc] = useState(false);

  // Opening an existing quotation from the Summary page loads it for editing.
  useEffect(() => {
    if (!editId) return;
    sbGet<Record<string, unknown>[]>(`quotations?id=eq.${editId}&select=*&limit=1`)
      .then((rows) => {
        const row = rows?.[0];
        if (!row) {
          toast.error("Quotation not found");
          return;
        }
        const savedLines = Array.isArray(row.lines) ? (row.lines as Line[]) : [];
        setDraft((d) => ({
          ...d,
          header: {
            ...d.header,
            date: String(row.date || row.created_at || today()).slice(0, 10),
            quoteNo: String(row.quote_no ?? ""),
            clientName: String(row.client_name ?? ""),
            clientAddress: String(row.client_address ?? ""),
          },
          lines: savedLines.length ? savedLines : d.lines,
          discount: Number(row.discount ?? 0),
          outstation: {
            enabled: Number(row.outstation_fee ?? 0) > 0,
            distance: d.outstation.distance,
          },
        }));
        toast.success(`Editing quotation ${row.quote_no ?? editId}`);
      })
      .catch((e: Error) => toast.error("Could not load quotation: " + e.message));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [editId]);


  const [services, setServices] = useState<Service[]>(FALLBACK_SERVICES);
  const [source, setSource] = useState<"loading" | "live" | "fallback" | "empty">("loading");
  const [servicesError, setServicesError] = useState<string | null>(null);

  const [mileage, setMileage] = useState({ flat_rate: 100, flat_km: 40, per_km_rate: 2.5 });

  useEffect(() => {
    sbGet<Service[]>("services?select=*&order=id")
      .then((data) => {
        if (data?.length) {
          setServices(data);
          setSource("live");
        } else setSource("empty");
      })
      .catch((e: Error) => {
        setServicesError(e.message);
        setSource("fallback");
      });

    sbGet<{ key: string; value: string }[]>("settings?select=*")
      .then((data) => {
        if (!Array.isArray(data)) return;
        const get = (key: string) => {
          const row = data.find((r) => r.key === key);
          return row ? parseFloat(row.value) : null;
        };
        setMileage({
          flat_rate: get("outstation_flat_rate") || 100,
          flat_km: get("outstation_flat_km") || 40,
          per_km_rate: get("outstation_per_km_rate") || 2.5,
        });
      })
      .catch(() => {});
  }, []);

  const updateHeader = (k: keyof typeof header, v: string) =>
    setHeader((h) => ({ ...h, [k]: v }));

  const updateLine = (id: number, k: keyof Line, v: string) =>
    setLines((ls) =>
      ls.map((x) => {
        if (x.id !== id) return x;
        if (k === "serviceId") {
          const svc = services.find((s) => s.id === Number(v));
          return {
            ...x,
            serviceId: v,
            description: svc?.description ?? "",
            unitPrice: svc?.unit_price ?? 0,
          };
        }
        return { ...x, [k]: v };
      }),
    );

  const outstationFee = useMemo(() => {
    if (!outstation.enabled) return 0;
    const d = parseFloat(outstation.distance) || 0;
    if (d <= 0) return 0;
    return d <= mileage.flat_km ? mileage.flat_rate : d * mileage.per_km_rate;
  }, [outstation, mileage]);

  const lineSubtotal = lines.reduce(
    (s, l) => s + (parseFloat(String(l.qty)) || 0) * (parseFloat(String(l.unitPrice)) || 0),
    0,
  );
  const subtotal = lineSubtotal + outstationFee;
  const discountAmt = parseFloat(String(discount)) || 0;
  const afterDiscount = subtotal - discountAmt;
  const sst = afterDiscount * 0.08;
  const rawTotal = afterDiscount + sst;
  const total = Math.round(rawTotal * 20) / 20;
  const rounding = total - rawTotal;

  const handleSave = async () => {
    setLoading(true);
    try {
      const payload = {
        quote_no: header.quoteNo,
        client_name: header.clientName,
        client_address: header.clientAddress,
        lines,
        outstation_fee: outstationFee,
        discount: discountAmt,
        subtotal,
        sst_amount: sst,
        total,
      };
      if (editId) await sbPatch(`quotations?id=eq.${editId}`, payload);
      else await sbInsert("quotations", payload);
      setSaved(true);
      clearDraft();
      toast.success(editId ? "Quotation updated" : "Quotation saved");
      setTimeout(() => setSaved(false), 3000);
    } catch (e) {
      toast.error("Save failed: " + (e as Error).message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <PageHeading
        title="Quotation Generator"
        subtitle="Build and save professional calibration service quotations"
      />

      <DraftBanner savedAt={savedAt} restored={restored} onDiscard={clearDraft} />


      <Panel title="Quotation Details" icon={<FileText className="size-4" />}>
        <div className="grid gap-4 sm:grid-cols-3">
          <div>
            <FieldLabel>Date</FieldLabel>
            <TextField
              type="date"
              value={header.date}
              onChange={(e) => updateHeader("date", e.target.value)}
            />
          </div>
          <div>
            <FieldLabel>Quote #</FieldLabel>
            <TextField value={header.quoteNo} onChange={(e) => updateHeader("quoteNo", e.target.value)} />
          </div>
          <div>
            <FieldLabel>SST ID No.</FieldLabel>
            <TextField value={header.sstId} onChange={(e) => updateHeader("sstId", e.target.value)} />
          </div>
        </div>
      </Panel>

      <Panel title="Client Information" icon={<Building2 className="size-4" />}>
        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <FieldLabel>Company Name</FieldLabel>
            <TextField
              value={header.clientName}
              placeholder="e.g. Soritsu Technology Sdn. Bhd"
              onChange={(e) => updateHeader("clientName", e.target.value)}
            />
          </div>
          <div>
            <FieldLabel>Address</FieldLabel>
            <TextField
              value={header.clientAddress}
              placeholder="City / State"
              onChange={(e) => updateHeader("clientAddress", e.target.value)}
            />
          </div>
        </div>
      </Panel>

      <Panel
        title="Line Items"
        icon={<Receipt className="size-4" />}
        action={
          source === "live" ? (
            <Pill tone="success">Live catalogue</Pill>
          ) : source === "loading" ? (
            <Pill tone="muted">Connecting…</Pill>
          ) : (
            <Pill tone="warning">{servicesError ? "Offline catalogue" : "No remote services"}</Pill>
          )
        }
      >
        <div className="-mx-2 overflow-x-auto">
          <table className="w-full min-w-[720px] border-collapse text-sm">
            <thead>
              <tr className="text-[10px] tracking-[0.1em] text-muted-foreground uppercase">
                {["#", "Service description", "Qty", "Unit price (RM)", "Amount (RM)", ""].map(
                  (h, i) => (
                    <th
                      key={h + i}
                      className={`border-b border-border px-3 py-2.5 ${i > 1 ? "text-right" : "text-left"}`}
                    >
                      {h}
                    </th>
                  ),
                )}
              </tr>
            </thead>
            <tbody>
              {lines.map((line, idx) => {
                const amount =
                  (parseFloat(String(line.qty)) || 0) * (parseFloat(String(line.unitPrice)) || 0);
                return (
                  <tr key={line.id} className="border-b border-border/60 last:border-0">
                    <td className="w-9 px-3 py-3 text-muted-foreground/70">{idx + 1}</td>
                    <td className="min-w-[280px] px-2 py-2">
                      <SelectField
                        value={line.serviceId}
                        onChange={(e) => updateLine(line.id, "serviceId", e.target.value)}
                      >
                        <option value="">— Select service —</option>
                        {services.map((s) => (
                          <option key={s.id} value={s.id}>
                            {s.description}
                          </option>
                        ))}
                      </SelectField>
                      {!line.serviceId && (
                        <TextField
                          className="mt-2"
                          placeholder="Or type a custom description…"
                          value={line.description}
                          onChange={(e) => updateLine(line.id, "description", e.target.value)}
                        />
                      )}
                    </td>
                    <td className="w-20 px-2 py-2">
                      <TextField
                        type="number"
                        min="1"
                        className="text-right"
                        value={line.qty}
                        onChange={(e) => updateLine(line.id, "qty", e.target.value)}
                      />
                    </td>
                    <td className="w-36 px-2 py-2">
                      <TextField
                        type="number"
                        step="0.01"
                        className="text-right"
                        value={line.unitPrice}
                        onChange={(e) => updateLine(line.id, "unitPrice", e.target.value)}
                      />
                    </td>
                    <td className="px-3 py-2 text-right font-semibold whitespace-nowrap">
                      {fmt(amount)}
                    </td>
                    <td className="w-10 px-2 py-2">
                      {lines.length > 1 && (
                        <button
                          onClick={() => setLines((l) => l.filter((x) => x.id !== line.id))}
                          className="rounded-lg p-2 text-destructive/70 transition-colors hover:bg-destructive/10 hover:text-destructive"
                          aria-label="Remove line"
                        >
                          <Trash2 className="size-4" />
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        <Button
          variant="outline"
          className="mt-4"
          onClick={() => setLines((l) => [...l, emptyLine()])}
        >
          <Plus className="size-4" /> Add line
        </Button>
      </Panel>

      <Panel title="Outstation / Travel Charges" icon={<Route className="size-4" />}>
        <label className="flex w-fit cursor-pointer items-center gap-3 text-sm">
          <input
            type="checkbox"
            checked={outstation.enabled}
            onChange={(e) => setOutstation((o) => ({ ...o, enabled: e.target.checked }))}
            className="size-4 accent-[oklch(0.443_0.209_265.3)]"
          />
          Apply outstation charges
        </label>

        {outstation.enabled && (
          <div className="mt-5 grid gap-4 sm:grid-cols-[220px_1fr] sm:items-end">
            <div>
              <FieldLabel>Distance from nearest branch (km)</FieldLabel>
              <TextField
                type="number"
                min="0"
                placeholder="e.g. 65"
                value={outstation.distance}
                onChange={(e) => setOutstation((o) => ({ ...o, distance: e.target.value }))}
              />
            </div>
            <div className="rounded-xl border border-primary/15 bg-primary/6 px-4 py-3">
              <p className="text-xs text-muted-foreground">
                {parseFloat(outstation.distance) > 0 &&
                parseFloat(outstation.distance) <= mileage.flat_km
                  ? `≤ ${mileage.flat_km} km → flat rate RM ${fmt(mileage.flat_rate)}`
                  : parseFloat(outstation.distance) > mileage.flat_km
                    ? `${outstation.distance} km × RM ${mileage.per_km_rate}/km`
                    : `≤ ${mileage.flat_km} km = RM ${fmt(mileage.flat_rate)} flat • > ${mileage.flat_km} km = RM ${mileage.per_km_rate}/km`}
              </p>
              <p className="text-gradient-brand mt-1 text-2xl font-extrabold">
                RM {fmt(outstationFee)}
              </p>
            </div>
          </div>
        )}
      </Panel>

      <Panel title="Summary" icon={<Receipt className="size-4" />}>
        <div className="ml-auto max-w-md space-y-1">
          <Row label="Subtotal" value={`RM ${fmt(subtotal)}`} />
          <div className="flex items-center justify-between border-b border-border/60 py-2.5 text-sm">
            <span className="text-muted-foreground">Discount</span>
            <div className="flex items-center gap-2">
              <span className="text-xs text-muted-foreground">RM</span>
              <TextField
                type="number"
                min="0"
                value={discount}
                onChange={(e) => setDiscount(e.target.value)}
                className="w-28 py-1.5 text-right"
              />
            </div>
          </div>
          <Row label="SST 8%" value={`RM ${fmt(sst)}`} />
          <div className="mt-2 flex items-center justify-between rounded-xl bg-gradient-brand px-4 py-3.5 text-primary-foreground shadow-lift">
            <span className="text-sm font-bold tracking-widest uppercase">Total</span>
            <span className="text-xl font-extrabold">RM {fmt(total)}</span>
          </div>
        </div>

        <div className="mt-6 border-t border-border/60 pt-5">
          <label className="flex w-fit cursor-pointer items-center gap-3 text-sm">
            <input
              type="checkbox"
              checked={signOn}
              onChange={(e) => setSignOn(e.target.checked)}
              className="size-4 accent-[oklch(0.443_0.209_265.3)]"
            />
            Add signature, name &amp; position (optional)
          </label>

          {signOn && (
            <div className="mt-4 space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <FieldLabel>Name</FieldLabel>
                  <TextField
                    value={sign.name}
                    placeholder="e.g. Ahmad Bin Ali"
                    onChange={(e) => setSign((s) => ({ ...s, name: e.target.value }))}
                  />
                </div>
                <div>
                  <FieldLabel>Position</FieldLabel>
                  <TextField
                    value={sign.position}
                    placeholder="e.g. Sales Manager"
                    onChange={(e) => setSign((s) => ({ ...s, position: e.target.value }))}
                  />
                </div>
              </div>
              <div>
                <FieldLabel>Signature</FieldLabel>
                <SignaturePad onSave={(dataUrl) => setSign((s) => ({ ...s, dataUrl }))} />
                {sign.dataUrl && (
                  <p className="mt-3">
                    <Pill tone="success">✓ Signature captured</Pill>
                  </p>
                )}
              </div>
            </div>
          )}
        </div>
      </Panel>

      <Panel title="Terms & Conditions" icon={<ScrollText className="size-4" />}>
        <ol className="list-decimal space-y-1.5 pl-5 text-sm leading-relaxed text-muted-foreground">
          {TERMS.map((t) => (
            <li key={t}>{t}</li>
          ))}
        </ol>
      </Panel>

      <div className="no-print flex flex-wrap justify-end gap-3 pb-6">
        <Button variant="outline" onClick={() => setShowDoc(true)}>
          <Printer className="size-4" /> Generate quotation document
        </Button>
        <Button onClick={handleSave} disabled={loading}>
          {loading ? "Saving…" : saved ? "✓ Saved" : "Save quotation"}
        </Button>
      </div>

      <DocumentPreview
        open={showDoc}
        onClose={() => setShowDoc(false)}
        title="Quotation — generated document"
      >
        <QuotationDocument
          data={{
            date: header.date,
            quoteNo: header.quoteNo,
            sstId: header.sstId,
            clientName: header.clientName,
            clientAddress: header.clientAddress,
            lines: lines
              .filter((l) => l.description)
              .map((l) => ({
                description: l.description,
                qty: parseFloat(String(l.qty)) || 0,
                unitPrice: parseFloat(String(l.unitPrice)) || 0,
              })),
            outstationFee,
            subtotal,
            discount: discountAmt,
            sst,
            rounding,
            total,
            signature: signOn ? sign.dataUrl : "",
            signName: signOn ? sign.name : "",
            signPosition: signOn ? sign.position : "",
          }}
        />
      </DocumentPreview>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between border-b border-border/60 py-2.5 text-sm">
      <span className="text-muted-foreground">{label}</span>
      <span className="font-semibold">{value}</span>
    </div>
  );
}
