import { useState } from "react";
import { UserRound, KeyRound, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Panel, FieldLabel, TextField, Pill, PageHeading } from "@/components/mcm/primitives";
import { SUPABASE_URL, SUPABASE_KEY } from "@/lib/mcm-api";
import { useAuth, initials } from "@/lib/auth";
import { toast } from "sonner";

export function SettingsPage() {
  const { user } = useAuth();
  const [currentPw, setCurrentPw] = useState("");
  const [newPw, setNewPw] = useState("");
  const [confirmPw, setConfirmPw] = useState("");
  const [saving, setSaving] = useState(false);

  if (!user) return null;

  const handleChangePw = async () => {
    if (!currentPw || !newPw || !confirmPw) return toast.error("Please fill in all fields.");
    if (newPw !== confirmPw) return toast.error("New passwords do not match.");
    if (newPw.length < 6) return toast.error("Password must be at least 6 characters.");

    setSaving(true);
    try {
      const headers = { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` };
      const res = await fetch(
        `${SUPABASE_URL}/rest/v1/mcm_users?username=eq.${encodeURIComponent(user.username)}&select=password`,
        { headers },
      );
      const data = await res.json();
      if (!data[0] || data[0].password !== currentPw) {
        toast.error("Current password is incorrect.");
        return;
      }
      await fetch(
        `${SUPABASE_URL}/rest/v1/mcm_users?username=eq.${encodeURIComponent(user.username)}`,
        {
          method: "PATCH",
          headers: { ...headers, "Content-Type": "application/json" },
          body: JSON.stringify({ password: newPw }),
        },
      );
      toast.success("Password changed successfully");
      setCurrentPw("");
      setNewPw("");
      setConfirmPw("");
    } catch {
      toast.error("Failed to update. Please try again.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <PageHeading title="Settings" subtitle="Manage your account preferences" />

      <Panel title="My Profile" icon={<UserRound className="size-4" />}>
        <div className="flex flex-wrap items-center gap-5">
          <span className="bg-gradient-brand shadow-lift flex size-16 items-center justify-center rounded-2xl text-2xl font-black text-primary-foreground">
            {initials(user)}
          </span>
          <div>
            <div className="text-lg font-extrabold">{user.full_name || user.username}</div>
            <div className="mt-0.5 text-sm text-muted-foreground">
              MCM ID: <strong className="text-primary">{user.username}</strong>
            </div>
            <div className="mt-2">
              <Pill tone={user.role === "admin" ? "brand" : "muted"}>
                <ShieldCheck className="size-3.5" /> {user.role || "staff"}
              </Pill>
            </div>
          </div>
        </div>
      </Panel>

      <Panel title="Change Password" icon={<KeyRound className="size-4" />}>
        <div className="grid gap-4 sm:grid-cols-3">
          {[
            { label: "Current password", val: currentPw, set: setCurrentPw },
            { label: "New password", val: newPw, set: setNewPw },
            { label: "Confirm password", val: confirmPw, set: setConfirmPw },
          ].map((f) => (
            <div key={f.label}>
              <FieldLabel>{f.label}</FieldLabel>
              <TextField
                type="password"
                value={f.val}
                onChange={(e) => f.set(e.target.value)}
                autoComplete="new-password"
              />
            </div>
          ))}
        </div>
        <Button className="mt-5" onClick={handleChangePw} disabled={saving}>
          {saving ? "Saving…" : "Update password"}
        </Button>
      </Panel>
    </div>
  );
}
