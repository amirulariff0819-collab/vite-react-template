import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/mcm/app-shell";
import { SummaryPage } from "@/components/mcm/summary-page";

export const Route = createFileRoute("/summary")({
  head: () => ({
    meta: [
      { title: "Summary & History — MCM LAB Portal" },
      {
        name: "description",
        content:
          "Full history of saved calibration quotations and service requests with totals, SST and client details.",
      },
      { property: "og:title", content: "Summary & History — MCM LAB Portal" },
      {
        property: "og:description",
        content: "Browse every saved quotation and service request in one place.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => (
    <AppShell title="Summary" subtitle="All saved quotations and service requests">
      <SummaryPage />
    </AppShell>
  ),
});
