import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/mcm/app-shell";
import { QuotationPage } from "@/components/mcm/quotation-page";

export const Route = createFileRoute("/quotation")({
  validateSearch: (search: Record<string, unknown>): { edit?: number } =>
    search.edit ? { edit: Number(search.edit) } : {},
  head: () => ({
    meta: [
      { title: "Quotation Generator — MCM LAB Portal" },
      {
        name: "description",
        content:
          "Create calibration service quotations with live service pricing, outstation mileage and SST 8% totals.",
      },
      { property: "og:title", content: "Quotation Generator — MCM LAB Portal" },
      {
        property: "og:description",
        content: "Build, price and save professional calibration quotations in minutes.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => (
    <AppShell title="Quotation Generator" subtitle="Generate and save calibration quotations">
      <QuotationPage />
    </AppShell>
  ),
});
