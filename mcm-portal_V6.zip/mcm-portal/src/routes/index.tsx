import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Eye, EyeOff, ArrowRight, AtSign } from "lucide-react";
import logoUrl from "@/assets/mcm-logo.png";
import { Button } from "@/components/ui/button";
import { FieldLabel, TextField } from "@/components/mcm/primitives";
import { SUPABASE_URL, SUPABASE_KEY, type McmUser } from "@/lib/mcm-api";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "MCM LAB Portal — Calibration Quotations & Service Requests" },
      {
        name: "description",
        content:
          "Secure staff portal for Metrology Corporation Malaysia: generate calibration quotations, submit service requests and manage accounts.",
      },
      { property: "og:title", content: "MCM LAB Portal — Staff Login" },
      {
        property: "og:description",
        content:
          "Sign in to the Metrology Corporation Malaysia portal for quotations, service requests and account settings.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: LoginPage,
});

function LoginPage() {
  const { user, ready, login } = useAuth();
  const navigate = useNavigate();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (ready && user) navigate({ to: "/dashboard" });
  }, [ready, user, navigate]);

  const handleLogin = async () => {
    if (!username || !password) {
      setError("Please enter your MCM ID and password.");
      return;
    }
    setLoading(true);
    setError("");
    const id = username.trim();
    try {
      const headers = { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` };

      // Preferred path: password is verified inside the database (bcrypt) and
      // never travels back to the browser. Requires supabase-security.sql.
      const rpc = await fetch(`${SUPABASE_URL}/rest/v1/rpc/mcm_login`, {
        method: "POST",
        headers: { ...headers, "Content-Type": "application/json" },
        body: JSON.stringify({ p_username: id, p_password: password }),
      });

      if (rpc.ok) {
        const rows = (await rpc.json()) as McmUser[];
        if (!rows || rows.length === 0) {
          setError("Incorrect MCM ID or password.");
          return;
        }
        login(rows[0]);
        navigate({ to: "/dashboard" });
        return;
      }

      // Fallback for databases where the security script has not been run yet.
      const res = await fetch(
        `${SUPABASE_URL}/rest/v1/mcm_users?username=eq.${encodeURIComponent(id)}&select=*`,
        { headers },
      );
      const data = (await res.json()) as McmUser[];
      if (!data || data.length === 0 || data[0].password !== password) {
        setError("Incorrect MCM ID or password.");
        return;
      }
      const found = data[0];
      fetch(`${SUPABASE_URL}/rest/v1/login_history`, {
        method: "POST",
        headers: { ...headers, "Content-Type": "application/json", Prefer: "return=minimal" },
        body: JSON.stringify({
          username: found.username,
          full_name: found.full_name,
          role: found.role,
        }),
      }).catch(() => {});
      login(found);
      navigate({ to: "/dashboard" });
    } catch {
      setError("Connection error. Please check your internet and try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="relative grid min-h-screen lg:grid-cols-[1.05fr_1fr]">
      {/* Brand panel */}
      <div className="bg-gradient-deep relative hidden overflow-hidden px-14 py-16 text-white lg:flex lg:flex-col lg:justify-center">
        <div className="absolute -top-32 -left-24 size-96 rounded-full bg-primary/45 blur-3xl" />
        <div className="absolute right-[-6rem] bottom-[-8rem] size-[26rem] rounded-full bg-primary/25 blur-3xl" />
        <div className="relative flex w-full max-w-md flex-col items-start text-left">
          <img
            src={logoUrl}
            alt="Metrology Corporation Malaysia logo"
            className="mb-10 block h-20 w-auto object-contain brightness-0 invert"
          />
          <h2 className="text-4xl leading-tight font-extrabold tracking-tight">
            Precision calibration,
            <span className="block text-white/55">managed end to end.</span>
          </h2>
          <p className="mt-4 text-sm leading-relaxed text-white/65">
            Quotations, service requests, digital signatures and staff activity — one workspace for
            the MCM laboratory team.
          </p>
          <div className="mt-8 flex flex-wrap gap-2">
            {["SST 8% ready", "Digital signature"].map((t) => (
              <span
                key={t}
                className="rounded-full border border-white/20 bg-white/8 px-3 py-1.5 text-xs font-semibold"
              >
                {t}
              </span>
            ))}
          </div>
        </div>
        <p className="absolute bottom-10 left-0 w-full text-center text-xs text-white/40">
          Metrology Corporation Malaysia Sdn. Bhd. © {new Date().getFullYear()}
        </p>
      </div>


      {/* Form panel */}
      <div className="flex items-center justify-center bg-background px-5 py-14">
        <div className="w-full max-w-md">
          <div className="mb-10 flex flex-col items-center justify-center gap-3 lg:hidden">
            <img
              src={logoUrl}
              alt="MCM logo"
              className="mx-auto block h-16 w-auto object-contain sm:h-20"
            />
          </div>

          <div className="surface p-6 sm:p-10">
            <h1 className="text-2xl font-extrabold tracking-tight">Staff sign in</h1>
            <p className="mt-1 mb-7 text-sm text-muted-foreground">
              Use your MCM ID and password to continue
            </p>

            <div className="space-y-5">
              <div>
                <FieldLabel>MCM ID</FieldLabel>
                <div className="relative">
                  <AtSign className="pointer-events-none absolute top-1/2 left-3.5 size-4 -translate-y-1/2 text-primary" />
                  <TextField
                    className="pl-10"
                    value={username}
                    placeholder="e.g. mcm2026"
                    onChange={(e) => {
                      setUsername(e.target.value);
                      setError("");
                    }}
                    onKeyDown={(e) => e.key === "Enter" && handleLogin()}
                  />
                </div>
              </div>

              <div>
                <FieldLabel>Password</FieldLabel>
                <div className="relative">
                  <TextField
                    className="pr-11"
                    type={showPw ? "text" : "password"}
                    value={password}
                    placeholder="Enter your password"
                    onChange={(e) => {
                      setPassword(e.target.value);
                      setError("");
                    }}
                    onKeyDown={(e) => e.key === "Enter" && handleLogin()}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPw((s) => !s)}
                    className="absolute top-1/2 right-3 -translate-y-1/2 rounded-md p-1 text-muted-foreground transition-colors hover:text-foreground"
                    aria-label={showPw ? "Hide password" : "Show password"}
                  >
                    {showPw ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
                  </button>
                </div>
              </div>

              {error && (
                <div className="rounded-xl border border-destructive/25 bg-destructive/8 px-4 py-3 text-sm text-destructive">
                  {error}
                </div>
              )}

              <Button className="h-12 w-full text-sm" onClick={handleLogin} disabled={loading}>
                {loading ? "Signing in…" : "Sign in"}
                {!loading && <ArrowRight className="size-4" />}
              </Button>
            </div>
          </div>

          <p className="mt-6 text-center text-xs text-muted-foreground lg:hidden">
            Metrology Corporation Malaysia Sdn. Bhd. © {new Date().getFullYear()}
          </p>
        </div>
      </div>
    </div>
  );
}
