import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/mcm/app-shell";
import { SettingsPage } from "@/components/mcm/settings-page";

export const Route = createFileRoute("/settings")({
  head: () => ({
    meta: [
      { title: "Account Settings — MCM LAB Portal" },
      {
        name: "description",
        content: "View your MCM staff profile and change your portal password securely.",
      },
      { property: "og:title", content: "Account Settings — MCM LAB Portal" },
      {
        property: "og:description",
        content: "Manage your MCM profile details and password.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => (
    <AppShell title="Settings" subtitle="Manage your account preferences">
      <SettingsPage />
    </AppShell>
  ),
});
