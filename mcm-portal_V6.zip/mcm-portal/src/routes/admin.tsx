import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/mcm/app-shell";
import { AdminPage } from "@/components/mcm/admin-page";

export const Route = createFileRoute("/admin")({
  head: () => ({
    meta: [
      { title: "Admin Console — MCM LAB Portal" },
      {
        name: "description",
        content:
          "Manage MCM staff accounts, calibration price list, sign-in history and auto-logout rules.",
      },
      { property: "og:title", content: "Admin Console — MCM LAB Portal" },
      {
        property: "og:description",
        content: "Staff accounts, pricing, login history and session controls in one place.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => (
    <AppShell title="Admin Console" subtitle="Users, pricing, login history & session rules">
      <AdminPage />
    </AppShell>
  ),
});
