import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/mcm/app-shell";
import { ServiceRequestPage } from "@/components/mcm/service-request-page";

export const Route = createFileRoute("/service-request")({
  validateSearch: (search: Record<string, unknown>): { edit?: number } =>
    search.edit ? { edit: Number(search.edit) } : {},
  head: () => ({
    meta: [
      { title: "Service Request Form — MCM LAB Portal" },
      {
        name: "description",
        content:
          "Submit calibration service requests with unlimited items, accessories and a digital signature.",
      },
      { property: "og:title", content: "Service Request Form — MCM LAB Portal" },
      {
        property: "og:description",
        content: "Log calibration items and capture a signed service request in one form.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => (
    <AppShell title="Service Request" subtitle="Submit calibration requests with signature">
      <ServiceRequestPage />
    </AppShell>
  ),
});
