import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/mcm/app-shell";
import { DashboardPage } from "@/components/mcm/dashboard-page";

export const Route = createFileRoute("/dashboard")({
  head: () => ({
    meta: [
      { title: "Overview — MCM LAB Portal" },
      {
        name: "description",
        content:
          "Dashboard overview of recent calibration quotations, service requests and quoted value for MCM staff.",
      },
      { property: "og:title", content: "Overview — MCM LAB Portal" },
      {
        property: "og:description",
        content: "Recent calibration quotations and service request activity at a glance.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => (
    <AppShell title="Overview" subtitle="Your calibration workspace at a glance">
      <DashboardPage />
    </AppShell>
  ),
});
