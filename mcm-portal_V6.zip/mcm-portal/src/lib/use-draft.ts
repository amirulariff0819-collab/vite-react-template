import { useCallback, useEffect, useRef, useState } from "react";
import { readSettings, subscribeSettings } from "./app-settings";

export function useAppSettings() {
  const [settings, setSettings] = useState(readSettings);
  useEffect(() => {
    setSettings(readSettings());
    return subscribeSettings(() => setSettings(readSettings()));
  }, []);
  return settings;
}

type DraftEnvelope<T> = { savedAt: number; data: T };

/**
 * State that survives reloads and accidental logouts.
 * The value is mirrored to localStorage (debounced) under a per-user key.
 */
export function useDraft<T>(key: string, initial: T) {
  const storageKey = `mcm.draft.${key}`;
  const [state, setState] = useState<T>(initial);
  const [savedAt, setSavedAt] = useState<number | null>(null);
  const [restored, setRestored] = useState(false);
  const hydrated = useRef(false);

  // hydrate once on the client
  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(storageKey);
      if (raw) {
        const env = JSON.parse(raw) as DraftEnvelope<T>;
        if (env && "data" in env) {
          setState(env.data);
          setSavedAt(env.savedAt);
          setRestored(true);
        }
      }
    } catch {
      /* ignore malformed drafts */
    }
    hydrated.current = true;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [storageKey]);

  // persist (debounced)
  useEffect(() => {
    if (!hydrated.current) return;
    if (!readSettings().autosaveDrafts) return;
    const t = window.setTimeout(() => {
      try {
        const savedTime = Date.now();
        window.localStorage.setItem(
          storageKey,
          JSON.stringify({ savedAt: savedTime, data: state } satisfies DraftEnvelope<T>),
        );
        setSavedAt(savedTime);
      } catch {
        /* quota exceeded — ignore */
      }
    }, 600);
    return () => window.clearTimeout(t);
  }, [state, storageKey]);

  const clear = useCallback(() => {
    window.localStorage.removeItem(storageKey);
    setSavedAt(null);
    setRestored(false);
    setState(initial);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [storageKey]);

  return { state, setState, savedAt, restored, clear };
}

export function clearAllDrafts() {
  if (typeof window === "undefined") return;
  Object.keys(window.localStorage)
    .filter((k) => k.startsWith("mcm.draft."))
    .forEach((k) => window.localStorage.removeItem(k));
}
