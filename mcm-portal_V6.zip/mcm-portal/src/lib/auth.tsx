import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import type { McmUser } from "./mcm-api";

const STORAGE_KEY = "mcm.session";
// Hard cap on a stored session, independent of the idle timer.
const MAX_SESSION_MS = 12 * 60 * 60 * 1000;

type StoredSession = { user: McmUser; issuedAt: number };

type AuthState = {
  user: McmUser | null;
  ready: boolean;
  login: (user: McmUser) => void;
  logout: () => void;
};

const AuthContext = createContext<AuthState | null>(null);

const sanitize = (u: McmUser): McmUser => ({
  id: u.id,
  username: u.username,
  full_name: u.full_name ?? null,
  role: u.role === "admin" ? "admin" : "staff",
});

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<McmUser | null>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as StoredSession | McmUser;
        const session = "user" in (parsed as StoredSession) ? (parsed as StoredSession) : null;
        if (session && Date.now() - session.issuedAt < MAX_SESSION_MS) {
          setUser(sanitize(session.user));
        } else {
          window.localStorage.removeItem(STORAGE_KEY);
        }
      }
    } catch {
      window.localStorage.removeItem(STORAGE_KEY);
    }
    setReady(true);
  }, []);

  const value = useMemo<AuthState>(
    () => ({
      user,
      ready,
      login: (u) => {
        const safe = sanitize(u);
        setUser(safe);
        window.localStorage.setItem(
          STORAGE_KEY,
          JSON.stringify({ user: safe, issuedAt: Date.now() } satisfies StoredSession),
        );
      },
      logout: () => {
        setUser(null);
        window.localStorage.removeItem(STORAGE_KEY);
      },
    }),
    [user, ready],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside AuthProvider");
  return ctx;
}

export const initials = (u: McmUser) => (u.full_name || u.username || "?").charAt(0).toUpperCase();
