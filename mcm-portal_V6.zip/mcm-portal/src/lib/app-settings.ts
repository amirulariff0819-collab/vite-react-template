// App-wide preferences persisted on the device and editable from the Admin page.
const KEY = "mcm.app-settings";
const EVENT = "mcm:settings-change";

export type AppSettings = {
  /** Minutes of inactivity before the session is closed automatically. */
  idleTimeoutMinutes: number;
  /** Warn this many seconds before the automatic logout fires. */
  idleWarningSeconds: number;
  /** Auto-save form drafts so nothing is lost on an accidental logout. */
  autosaveDrafts: boolean;
};

export const DEFAULT_SETTINGS: AppSettings = {
  idleTimeoutMinutes: 2,
  idleWarningSeconds: 20,
  autosaveDrafts: true,
};

export function readSettings(): AppSettings {
  if (typeof window === "undefined") return DEFAULT_SETTINGS;
  try {
    const raw = window.localStorage.getItem(KEY);
    if (!raw) return DEFAULT_SETTINGS;
    return { ...DEFAULT_SETTINGS, ...(JSON.parse(raw) as Partial<AppSettings>) };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

export function writeSettings(next: Partial<AppSettings>) {
  const merged = { ...readSettings(), ...next };
  window.localStorage.setItem(KEY, JSON.stringify(merged));
  window.dispatchEvent(new CustomEvent(EVENT));
  return merged;
}

export function subscribeSettings(cb: () => void) {
  const handler = () => cb();
  window.addEventListener(EVENT, handler);
  window.addEventListener("storage", handler);
  return () => {
    window.removeEventListener(EVENT, handler);
    window.removeEventListener("storage", handler);
  };
}
