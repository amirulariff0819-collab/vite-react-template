// Lightweight REST client for the MCM backend (PostgREST compatible).
export const SUPABASE_URL = "https://ztfulztfuialhckmiirc.supabase.co";
export const SUPABASE_KEY = "sb_publishable_YWjWdyGmLuyxzKehhg2Mdg_Z3dayh16";

const headers = (extra: Record<string, string> = {}) => ({
  apikey: SUPABASE_KEY,
  Authorization: `Bearer ${SUPABASE_KEY}`,
  ...extra,
});

export type McmUser = {
  id?: number | string;
  username: string;
  full_name?: string | null;
  role?: string | null;
  password?: string;
};

export type Service = { id: number; description: string; unit_price: number };

// Official MCM Calibration Lab price list — May 2025.
export const FALLBACK_SERVICES: Service[] = [
  { id: 1, description: "Weighing Scale — Capacity ≤ 10 kg", unit_price: 130 },
  { id: 2, description: "Weighing Scale — 10 kg < Capacity ≤ 50 kg", unit_price: 150 },
  { id: 3, description: "Weighing Scale — 50 kg < Capacity ≤ 300 kg", unit_price: 170 },
  {
    id: 4,
    description: "Weighing Scale — 300 kg < Capacity ≤ 500 kg (Full Weights)",
    unit_price: 300,
  },
  {
    id: 5,
    description: "Weighing Scale — 300 kg < Capacity ≤ 500 kg (Substitution Load)",
    unit_price: 260,
  },
  {
    id: 6,
    description: "Weighing Scale — 500 kg < Capacity ≤ 1,000 kg (Full Weights)",
    unit_price: 600,
  },
  {
    id: 7,
    description: "Weighing Scale — 500 kg < Capacity ≤ 1,000 kg (Substitution Load)",
    unit_price: 520,
  },
  {
    id: 8,
    description: "Weighing Scale — 1,000 kg < Capacity ≤ 3,000 kg (Full Weights)",
    unit_price: 1275,
  },
  {
    id: 9,
    description: "Weighing Scale — 1,000 kg < Capacity ≤ 3,000 kg (Substitution Load)",
    unit_price: 1100,
  },
  {
    id: 10,
    description: "Weighing Scale — 3,000 kg < Capacity ≤ 5,000 kg (Full Weights)",
    unit_price: 1800,
  },
  {
    id: 11,
    description: "Weighing Scale — 3,000 kg < Capacity ≤ 5,000 kg (Substitution Load)",
    unit_price: 1600,
  },
  {
    id: 12,
    description: "Weighing Scale — 5,000 kg < Capacity ≤ 10,000 kg (Full Weights)",
    unit_price: 2250,
  },
  {
    id: 13,
    description: "Weighing Scale — 5,000 kg < Capacity ≤ 10,000 kg (Substitution Load)",
    unit_price: 2000,
  },
  {
    id: 14,
    description: "Weighing Scale — 10,000 kg < Capacity ≤ 20,000 kg (Substitution Load)",
    unit_price: 2900,
  },
  {
    id: 15,
    description: "Weighing Scale — 20,000 kg < Capacity ≤ 30,000 kg (Substitution Load)",
    unit_price: 3900,
  },
  { id: 16, description: "Test Weight F1/F2/M1 — 1 mg to 500 mg (Set/cert)", unit_price: 15 },
  { id: 17, description: "Test Weight F1/F2/M1 — 1 mg to 500 mg (Single pcs)", unit_price: 36 },
  { id: 18, description: "Test Weight F1/F2/M1 — 1 g to 20 g (Set/cert)", unit_price: 15 },
  { id: 19, description: "Test Weight F1/F2/M1 — 1 g to 20 g (Single pcs)", unit_price: 36 },
  { id: 20, description: "Test Weight F1/F2/M1 — 50 g to 100 g (Set/cert)", unit_price: 18 },
  { id: 21, description: "Test Weight F1/F2/M1 — 50 g to 100 g (Single pcs)", unit_price: 40 },
  { id: 22, description: "Test Weight F1/F2/M1 — 200 g to 2 kg (Set/cert)", unit_price: 18 },
  { id: 23, description: "Test Weight F1/F2/M1 — 200 g to 2 kg (Single pcs)", unit_price: 40 },
  { id: 24, description: "Test Weight F1/F2/M1 — 5 kg to 20 kg", unit_price: 40 },
  { id: 25, description: "Weight (non-standard notation) — 2 g < notation < 1 kg", unit_price: 40 },
  {
    id: 26,
    description: "Weight (non-standard notation) — 1 kg < notation < 20 kg",
    unit_price: 60,
  },
  { id: 27, description: "Cast Iron Weight — 500 g < m ≤ 20 kg (Set/cert)", unit_price: 20 },
  { id: 28, description: "Cast Iron Weight — 500 g < m ≤ 20 kg (Single pcs)", unit_price: 40 },
  { id: 29, description: "Cast Iron Weight — 20 kg < m ≤ 30 kg (Set/cert)", unit_price: 30 },
  { id: 30, description: "Cast Iron Weight — 20 kg < m ≤ 30 kg (Single pcs)", unit_price: 60 },
  { id: 31, description: "Cast Iron Weight — 30 kg < m ≤ 50 kg (Set/cert)", unit_price: 50 },
  { id: 32, description: "Cast Iron Weight — 30 kg < m ≤ 50 kg (Single pcs)", unit_price: 85 },
  { id: 33, description: "Cast Iron Weight — 250 kg", unit_price: 160 },
  { id: 34, description: "Cast Iron Weight — 1,000 kg", unit_price: 650 },
  { id: 35, description: "Reprint / Reissue Certificate", unit_price: 20 },
  { id: 36, description: "Outstation charge — 40 km and below", unit_price: 100 },
  { id: 37, description: "Outstation charge — more than 40 km (per km)", unit_price: 2.5 },
];


async function handle(res: Response) {
  if (!res.ok) {
    const err = await res.json().catch(() => ({}) as { message?: string });
    throw new Error(err.message || `HTTP ${res.status}`);
  }
  const text = await res.text();
  return text ? JSON.parse(text) : null;
}

const BLOCKED =
  "The database rejected this change (no rows affected). Run supabase-security.sql in the Supabase SQL editor to grant write access.";

// A write that returns an empty representation means row-level security silently
// blocked it — surface that instead of pretending the change was saved.
function assertWrote<T>(rows: T): T {
  if (Array.isArray(rows) && rows.length === 0) throw new Error(BLOCKED);
  return rows;
}

export const sbGet = async <T,>(path: string): Promise<T> =>
  handle(await fetch(`${SUPABASE_URL}/rest/v1/${path}`, { headers: headers() }));

export const sbRpc = async <T,>(fn: string, args: Record<string, unknown>): Promise<T> =>
  handle(
    await fetch(`${SUPABASE_URL}/rest/v1/rpc/${fn}`, {
      method: "POST",
      headers: headers({ "Content-Type": "application/json" }),
      body: JSON.stringify(args),
    }),
  );

export const sbInsert = async <T,>(table: string, body: unknown): Promise<T> =>
  assertWrote(
    await handle(
      await fetch(`${SUPABASE_URL}/rest/v1/${table}`, {
        method: "POST",
        headers: headers({ "Content-Type": "application/json", Prefer: "return=representation" }),
        body: JSON.stringify(body),
      }),
    ),
  );

export const sbPatch = async <T,>(path: string, body: unknown): Promise<T> =>
  assertWrote(
    await handle(
      await fetch(`${SUPABASE_URL}/rest/v1/${path}`, {
        method: "PATCH",
        headers: headers({ "Content-Type": "application/json", Prefer: "return=representation" }),
        body: JSON.stringify(body),
      }),
    ),
  );

export const sbDelete = async (path: string): Promise<void> => {
  assertWrote(
    await handle(
      await fetch(`${SUPABASE_URL}/rest/v1/${path}`, {
        method: "DELETE",
        headers: headers({ Prefer: "return=representation" }),
      }),
    ),
  );
};


// ─── formatting helpers ───────────────────────────────────────────────
export const fmt = (n: number | undefined | null) =>
  (n ?? 0).toLocaleString("en-MY", { minimumFractionDigits: 2, maximumFractionDigits: 2 });

export const today = () => new Date().toISOString().split("T")[0];
