import { useEffect, useRef, useState } from "react";
import { useAppSettings } from "@/lib/use-draft";

const ACTIVITY = ["mousemove", "mousedown", "keydown", "touchstart", "scroll", "wheel", "focus"];

/**
 * Signs the user out after a configurable period of inactivity.
 * Shows a countdown for the last few seconds so it never feels abrupt.
 */
export function useIdleLogout(onTimeout: () => void) {
  const { idleTimeoutMinutes, idleWarningSeconds } = useAppSettings();
  const [secondsLeft, setSecondsLeft] = useState<number | null>(null);
  const lastActivity = useRef(Date.now());
  const fired = useRef(false);
  const cb = useRef(onTimeout);
  cb.current = onTimeout;

  useEffect(() => {
    const limitMs = Math.max(0.5, idleTimeoutMinutes) * 60_000;
    if (!Number.isFinite(limitMs) || limitMs <= 0) return;

    const bump = () => {
      lastActivity.current = Date.now();
      setSecondsLeft(null);
    };
    ACTIVITY.forEach((e) => window.addEventListener(e, bump, { passive: true }));

    const tick = window.setInterval(() => {
      const idle = Date.now() - lastActivity.current;
      const remaining = Math.ceil((limitMs - idle) / 1000);
      if (remaining <= 0) {
        if (fired.current) return;
        fired.current = true;
        cb.current();
      } else if (remaining <= idleWarningSeconds) {
        setSecondsLeft(remaining);
      }
    }, 1000);

    return () => {
      ACTIVITY.forEach((e) => window.removeEventListener(e, bump));
      window.clearInterval(tick);
    };
  }, [idleTimeoutMinutes, idleWarningSeconds]);

  const stayActive = () => {
    lastActivity.current = Date.now();
    setSecondsLeft(null);
  };

  return { secondsLeft, stayActive, idleTimeoutMinutes };
}
