-- ============================================================
-- MCM LAB Portal — required Supabase policies
-- Run this once in Supabase → SQL Editor.
-- It lets the portal add/remove users and update the price list.
-- ============================================================

-- ---------- services (price list) ----------
alter table public.services enable row level security;

grant select, insert, update, delete on public.services to anon, authenticated;
grant usage, select on all sequences in schema public to anon, authenticated;

drop policy if exists "services read"   on public.services;
drop policy if exists "services write"  on public.services;

create policy "services read"  on public.services for select using (true);
create policy "services write" on public.services for all    using (true) with check (true);

-- ---------- mcm_users (staff accounts) ----------
alter table public.mcm_users enable row level security;

grant select, insert, update, delete on public.mcm_users to anon, authenticated;

drop policy if exists "users read"  on public.mcm_users;
drop policy if exists "users write" on public.mcm_users;

create policy "users read"  on public.mcm_users for select using (true);
create policy "users write" on public.mcm_users for all    using (true) with check (true);

-- ---------- login_history ----------
alter table public.login_history enable row level security;

grant select, insert on public.login_history to anon, authenticated;

drop policy if exists "login history read"   on public.login_history;
drop policy if exists "login history insert" on public.login_history;

create policy "login history read"   on public.login_history for select using (true);
create policy "login history insert" on public.login_history for insert with check (true);

-- ============================================================
-- Price List — MCM Calibration Lab, May 2025
-- Replaces the services table contents with the current list.
-- ============================================================
truncate table public.services restart identity cascade;

insert into public.services (description, unit_price) values
  ('Weighing Scale — Capacity ≤ 10 kg', 130),
  ('Weighing Scale — Capacity 11 kg to 60 kg', 150),
  ('Weighing Scale — Capacity 61 kg to 150 kg', 180),
  ('Weighing Scale — Capacity 151 kg to 300 kg', 220),
  ('Weighing Scale — Capacity 301 kg to 600 kg', 280),
  ('Weighing Scale — Capacity 601 kg to 1000 kg', 350),
  ('Weighing Scale — Capacity 1001 kg to 2000 kg', 450),
  ('Weighing Scale — Capacity 2001 kg to 3000 kg', 550),
  ('Weighing Scale — Capacity above 3000 kg', 700),
  ('Analytical Balance — Readability 0.1 mg', 250),
  ('Analytical Balance — Readability 0.01 mg', 320),
  ('Precision Balance — Readability 1 mg to 10 mg', 200),
  ('Test Weight — Class F1 (per piece)', 60),
  ('Test Weight — Class F2 (per piece)', 45),
  ('Test Weight — Class M1 (per piece)', 30),
  ('Thermometer — Digital / Dial (per point)', 80),
  ('Thermometer — Liquid in glass (per point)', 90),
  ('Data Logger — Temperature (per channel)', 120),
  ('Temperature & Humidity Meter (per point)', 150),
  ('Oven / Incubator — Temperature mapping (per unit)', 450),
  ('Refrigerator / Chiller — Temperature mapping', 400),
  ('Autoclave — Temperature & pressure verification', 500),
  ('Pressure Gauge — Range ≤ 100 bar', 160),
  ('Pressure Gauge — Range above 100 bar', 220),
  ('Torque Wrench — Capacity ≤ 100 Nm', 180),
  ('Torque Wrench — Capacity above 100 Nm', 240),
  ('Vernier Caliper — up to 300 mm', 90),
  ('Micrometer — up to 100 mm', 90),
  ('Dial Gauge / Dial Indicator', 85),
  ('Measuring Tape / Steel Rule — per 1 m', 60),
  ('pH Meter (per unit)', 180),
  ('Conductivity Meter (per unit)', 180),
  ('Tachometer (per unit)', 150),
  ('Stopwatch / Timer (per unit)', 100),
  ('On-site calibration surcharge (per trip)', 250),
  ('Outstation charge — 40 km and below', 100),
  ('Outstation charge — more than 40 km (per km)', 2.5);
