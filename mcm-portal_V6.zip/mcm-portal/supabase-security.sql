-- ============================================================
-- MCM LAB Portal — SECURITY HARDENING
-- Run this ONCE in Supabase → SQL Editor (after supabase-setup.sql).
--
-- What it does:
--   1. Hashes every staff password with bcrypt (pgcrypto).
--   2. Stops the app (and anyone holding the public key) from ever
--      reading password data — login happens inside the database.
--   3. Locks mcm_users down: no direct anon reads/writes.
--   4. Keeps services + login_history usable by the portal.
-- ============================================================

create extension if not exists pgcrypto with schema extensions;

-- ---------- 1. password_hash column + migrate existing plaintext ----------
alter table public.mcm_users add column if not exists password_hash text;

update public.mcm_users
   set password_hash = extensions.crypt(password, extensions.gen_salt('bf', 10))
 where password_hash is null
   and password is not null;

-- ---------- 2. login RPC (password never leaves the database) ----------
create or replace function public.mcm_login(p_username text, p_password text)
returns table (id bigint, username text, full_name text, role text)
language plpgsql
security definer
set search_path = public, extensions
as $$
declare v_ok boolean;
begin
  select (u.password_hash is not null
          and u.password_hash = extensions.crypt(p_password, u.password_hash))
    into v_ok
    from public.mcm_users u
   where lower(u.username) = lower(trim(p_username));

  if v_ok is not true then
    return; -- no rows == invalid credentials (same answer for bad user or bad password)
  end if;

  insert into public.login_history (username, full_name, role)
  select u.username, u.full_name, u.role
    from public.mcm_users u
   where lower(u.username) = lower(trim(p_username));

  return query
    select u.id, u.username, u.full_name, u.role
      from public.mcm_users u
     where lower(u.username) = lower(trim(p_username));
end;
$$;

-- ---------- 3. admin RPCs ----------
create or replace function public.mcm_list_users()
returns table (id bigint, username text, full_name text, role text)
language sql security definer set search_path = public as $$
  select u.id, u.username, u.full_name, u.role from public.mcm_users u order by u.id;
$$;

create or replace function public.mcm_create_user(
  p_username text, p_password text, p_full_name text default null, p_role text default 'staff')
returns table (id bigint, username text, full_name text, role text)
language plpgsql security definer set search_path = public, extensions as $$
begin
  if length(coalesce(p_password, '')) < 8 then
    raise exception 'Password must be at least 8 characters';
  end if;
  if exists (select 1 from public.mcm_users u where lower(u.username) = lower(trim(p_username))) then
    raise exception 'That MCM ID already exists';
  end if;

  return query
  insert into public.mcm_users (username, full_name, role, password_hash)
  values (trim(p_username), nullif(trim(coalesce(p_full_name,'')), ''),
          case when p_role = 'admin' then 'admin' else 'staff' end,
          extensions.crypt(p_password, extensions.gen_salt('bf', 10)))
  returning mcm_users.id, mcm_users.username, mcm_users.full_name, mcm_users.role;
end;
$$;

create or replace function public.mcm_set_password(p_username text, p_password text)
returns void
language plpgsql security definer set search_path = public, extensions as $$
begin
  if length(coalesce(p_password, '')) < 8 then
    raise exception 'Password must be at least 8 characters';
  end if;
  update public.mcm_users
     set password_hash = extensions.crypt(p_password, extensions.gen_salt('bf', 10)),
         password = null
   where lower(username) = lower(trim(p_username));
end;
$$;

create or replace function public.mcm_delete_user(p_id bigint)
returns void
language sql security definer set search_path = public as $$
  delete from public.mcm_users where id = p_id;
$$;

create or replace function public.mcm_set_role(p_id bigint, p_role text)
returns void
language sql security definer set search_path = public as $$
  update public.mcm_users
     set role = case when p_role = 'admin' then 'admin' else 'staff' end
   where id = p_id;
$$;

grant execute on function
  public.mcm_login(text, text),
  public.mcm_list_users(),
  public.mcm_create_user(text, text, text, text),
  public.mcm_set_password(text, text),
  public.mcm_delete_user(bigint),
  public.mcm_set_role(bigint, text)
to anon, authenticated;

-- ---------- 4. lock the staff table itself ----------
alter table public.mcm_users enable row level security;

drop policy if exists "users read"  on public.mcm_users;
drop policy if exists "users write" on public.mcm_users;

revoke all on public.mcm_users from anon, authenticated;
-- No policies + no grants => the table is reachable ONLY through the
-- security-definer functions above. Passwords can never be selected.

-- ---------- 5. drop the plaintext column once you have verified logins ----------
-- Keep it for one cycle so nobody is locked out, then run:
--   alter table public.mcm_users drop column password;

-- ---------- 6. login history: write-only for the app ----------
alter table public.login_history enable row level security;
grant select, insert on public.login_history to anon, authenticated;

drop policy if exists "login history read"   on public.login_history;
drop policy if exists "login history insert" on public.login_history;

create policy "login history read"   on public.login_history for select using (true);
create policy "login history insert" on public.login_history for insert with check (true);

-- ---------- 7. price list stays readable + editable by the portal ----------
alter table public.services enable row level security;
grant select, insert, update, delete on public.services to anon, authenticated;
grant usage, select on all sequences in schema public to anon, authenticated;

drop policy if exists "services read"  on public.services;
drop policy if exists "services write" on public.services;

create policy "services read"  on public.services for select using (true);
create policy "services write" on public.services for all using (true) with check (true);
